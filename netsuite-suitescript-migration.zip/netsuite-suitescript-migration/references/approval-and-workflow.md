# Approval Gate & Workflow Details

Expanded detail behind the short "Approval Gate" section in `SKILL.md`. Read this before running Convert
Mode, or an Analyze Mode pass across multiple files.

## The gate itself

Invoking this skill — even with no arguments, even if it was auto-triggered by opening a SuiteScript 1.0
file — only means the skill's instructions are now loaded. It is never itself a request to analyze or
convert anything. Before Convert Mode (or a multi-file Analyze Mode pass) does any real work, stop and
confirm these in **one short message**, then wait for an explicit go-ahead:

1. **Scope.** Exactly which file(s): a single named file, or every matching SS1.0 file in a directory. A
   file simply being open in the user's editor, or having come up earlier in the conversation, is not
   implicit approval to treat it as the conversion target — ask. If the scope is "all files in a
   directory," build the inventory table (`node scripts/validate-migration.js inventory <dir>`) and get
   the batch order confirmed before converting any individual file in it.
2. **Target version.** State the default (`--target 2.1`, or whatever this project's existing
   `@NApiVersion` convention points at) explicitly and confirm it's still correct rather than assuming it
   — don't silently default either direction. See "Target Version" in `SKILL.md`.
3. **Output mode.** Side-by-side (default — write the new file next to the original, which stays
   untouched) or convert-in-place (only offered when the target file is Git-tracked and clean). See
   "Output Location Mode" below.

Ask all three in a single short message, not three separate round-trips. This gate applies to every
conversion request, not just the first one in a session — if the user asks for a second file after the
first is done, confirm scope/version/output-mode for that one too rather than assuming they carry over
unchanged.

**Once this gate is satisfied, write the converted file directly — don't pause again to ask whether to
save it.** The approval already covers that; a second "should I actually write this?" prompt after
scope, version, and output mode are confirmed is friction the user has explicitly asked this skill not to
add.

## If converting to the SuiteScript 2.0 override: mention the end-of-life timeline

When a file's target is explicitly confirmed as the SS2.0 (ES5-only) override rather than this skill's
2.1 default, add this to the approval-gate confirmation so the user is choosing it knowingly, not by
default:

> NetSuite's published removal schedule (Help Center topic "Transitioning to SuiteScript 2.1"): starting
> **2027.1**, SuiteScript 1.0 support narrows to critical issues only; starting **2028.1**, scripts
> annotated `@NApiVersion 2.0` or `2.x` begin running on the 2.1 engine by default; by **2028.2**, every
> custom script must be on 2.1 to keep running. Converting to 2.0 now means a second migration later —
> confirm this is still the intended target before proceeding.

**UNVERIFIED against the primary source:** these dates are corroborated by secondary sources (e.g.
randgroup.com's and rsmus.com's writeups of the announcement) but this skill could not fetch the primary
Oracle Help Center page directly to quote its exact wording — confirm the exact dates in your own
account's Help Center → "Transitioning to SuiteScript 2.1" page before treating them as final, since
Oracle has adjusted migration-deadline details across releases.

## Output Location Mode

Default: **side-by-side**. Keep the original SS1.0 file untouched at its existing path, and write the
converted file next to it (naming convention: agree on this with the user if not obvious — e.g. a
sibling `ss2/` directory, or a `_v2` suffix). This keeps rollback and cutover possible without relying
solely on `git` history, and is the only safe choice when the file isn't tracked or has uncommitted
changes.

**Convert-in-place** (edit the original file directly) is only offered — never defaulted to — when the
target file is Git-tracked with a clean working tree for that file. Even then, it's the user's call, not
the default:
- Check `git status` on the target file.
- If it's tracked with a clean history, in-place is safe to offer (`git` is the recovery path).
- If it's untracked (no commit exists for it) or has uncommitted changes, side-by-side is the only option
  — don't offer in-place, and don't silently back up and overwrite either. Mention the backup/side-by-side
  choice and where the new file will go; don't ask permission for the backup step itself once side-by-side
  is the agreed mode, just do it and say so.

After writing the converted file, run `scripts/validate-migration.js` against it and report the result.
If validation fails (including from something external like an editor auto-reformatting the file after
the fact), fix it and re-validate rather than leaving a broken file in place.

## Batch Migration Strategy

For projects with many SS1.0 scripts:

1. **Inventory first** — run `node scripts/validate-migration.js inventory <dir>` to assess total scope
   before converting anything.
2. **Shared libraries first** — convert utility/helper scripts before scripts that depend on them (see
   `business-logic-preservation.md`'s Dependency Discovery section); converting a dependent script before
   its library is migrated produces a script that can't load.
3. **Prioritize low complexity** — convert Low-complexity scripts first to build confidence and catch
   process issues early.
4. **Group by type** — convert all User Events together, then Client Scripts, etc., so entry-point
   patterns stay fresh.
5. **One report per script** — every migrated script gets its own `migration-report-template.md`
   instance; don't batch multiple scripts into one report.
6. **Test incrementally** — deploy and test each batch (per `sandbox-test-checklist.md`) before moving to
   the next; don't queue up a large batch of unvalidated conversions.
7. **Coexistence period** — keep SS1.0 scripts available as a reference/rollback path during the
   validation phase, whether that's the side-by-side file or Git history.

## MIGRATION-REVIEW markers

Keep comments in converted code minimal (see `SKILL.md`). The one required exception: leave a short
`// MIGRATION-REVIEW: <reason>` comment at every spot left genuinely unresolved (an ambiguous business
rule, an assumption that needs confirming, a Do-Not-Guess item that didn't block the rest of the file).
List every one of these, with line number and reason, in that script's migration report — don't let one
get silently lost in the diff.

## Completion language

**Allowed**, once applicable: "converted," "statically validated with the checker and manual diff
review," "ready for Sandbox testing."

**Not allowed** without actual Sandbox results backing it up: "fully validated," "tested,"
"production-ready," "no behavior change." Static checks are necessary, not sufficient — see
`business-logic-preservation.md`'s Migration Status Taxonomy and `sandbox-test-checklist.md`.
