# Business Logic Preservation

This is the expanded reference for the "Business Logic Preservation" section at
the top of `SKILL.md`. The Oracle original this skill is adapted from is strong on
mechanical API correctness but doesn't state these rules explicitly — they're
layered on here because a migration that silently changes behavior while looking
syntactically correct is worse than no migration, especially at scale across many
scripts.

## The Core Principle

A SuiteScript 1.0 script that's been running in production encodes real business
decisions in its conditions and edge cases, even the ones that look odd or
redundant on a casual read. The API changed between 1.0 and 2.0; the business did
not. Every conversion decision should be checked against one question: *does this
change what the script does, or only how it says it?* If the answer isn't
confidently "only how it says it," that's the signal to flag the ambiguity rather
than push forward — see "Do Not Guess" below.

## Never Rename Custom IDs

`custbody_`, `custcol_`, `custrecord_`, `custitem_`, `customrecord_`,
`customscript_`, `customdeploy_`, and any custom list/form/status/transaction ID
stay character-for-character identical through the conversion. These IDs are
referenced by saved searches, workflows, reports, and other scripts outside the
file being converted — renaming one, even one that looks like a typo or an
inconsistent naming convention, breaks everything else that references it.

## Required Migration Change vs. Optional Improvement

Keep these two categories strictly separate in every report this skill produces
(Analyze, Convert, or Validate Mode output):

- **Required migration change**: a 1:1 API swap that doesn't alter behavior —
  `nlapiLoadRecord` → `record.load`, 1-based → 0-based sublist indexing (the index
  arithmetic changes, but the record being read doesn't), positional args → options
  objects.
- **Optional improvement**: anything that changes the script's structure,
  architecture, or efficiency beyond what the API conversion strictly requires.

### Worked Example: Scheduled Script with Recovery Points

`SKILL.md`'s Pattern 15 shows a Scheduled Script using
`nlapiSetRecoveryPoint`/`nlapiYieldScript` being converted straight to a
Map/Reduce script, framed as "recommended." Treat that framing as the *optional*
branch, not the default:

- **Preservation-first option (default):** keep it a Scheduled Script. There's no
  direct 2.0 equivalent for `nlapiSetRecoveryPoint`'s exact resume-at-this-item
  behavior, so the honest trade-off is: reschedule via `task.create({ taskType:
  task.TaskType.SCHEDULED_SCRIPT, ... }).submit()` on low governance (same
  mechanism every other Scheduled Script migration uses), and accept that the
  rescheduled run restarts its search/loop from the top rather than resuming at
  the exact unprocessed item. This keeps the script's architecture, trigger
  conditions, and deployment identical — the only behavior change is the resume
  granularity, which should be called out explicitly in the migration report, not
  silently absorbed.
- **Map/Reduce option (optional, separate recommendation):** genuinely better for
  large result sets since each `map`/`reduce` invocation gets its own governance
  bucket with automatic retry — but this is an architecture change (new script
  type, new deployment, different governance/retry semantics than the original
  ever had) and belongs in its own conversation with the user, not folded into a
  "migration."

Apply the same required-vs-optional split to any other spot where the mechanical
conversion is awkward: don't reach for a bigger rewrite as the default just because
it's cleaner — offer it alongside the behavior-preserving option and let the user
pick.

## Don't Remove "Dead" Code

A condition or branch that looks unreachable, redundant, or vestigial might exist
because of an edge case hit once in production that isn't obvious from reading the
code in isolation. Flag it as suspicious, explain why it looks that way, and keep
it unless its removal is explicitly approved.

## Do Not Guess

If the migration hits something ambiguous — an unknown custom module, undocumented
API behavior, a missing referenced file, an unclear script type, a missing saved
search or custom field, or an API with no clear 2.0 equivalent that isn't already
covered in `references/unmapped-apis.md` — don't invent an answer:

1. Name the specific thing that's ambiguous.
2. Search the repository for evidence (grep for the ID, look for sibling
   deployments, check for a shared library) before concluding anything.
3. If it's still unresolved, flag it plainly rather than silently picking an
   interpretation — in Analyze/Convert Mode output, this means a "Blocked" item
   (see below); in Validate Mode output, a Critical or High finding depending on
   severity.
4. Keep converting everything else in the script that *is* safe to convert — one
   unresolved item shouldn't block the whole file.

## Migration Status Taxonomy

Oracle's Validate Mode already reports Critical/High/Medium/Low findings with a
PASS/FAIL result — keep using that for per-issue severity. Layer this status on
top of it for the overall state of a migrated script, since "syntactically valid"
and "ready to deploy" are different claims:

- **Converted** — API migration complete, Validate Mode passes (no Critical/High
  findings), nothing flagged as blocking. Still requires Sandbox testing before
  being considered production-ready — syntax and API correctness are necessary,
  not sufficient.
- **Needs review** — conversion is complete but something non-blocking was
  flagged (a suspicious pre-existing code pattern, an assumption about a missing
  dependency, an ambiguous business rule) that a human should look at before
  sign-off.
- **Requires testing** — same as Converted, but used when the script has
  high-risk characteristics (heavy governance use, external integrations, complex
  sublist logic, the recovery-point/Map-Reduce trade-off above) that specifically
  warrant calling out Sandbox testing as non-optional, not just a formality.
- **Blocked** — something in Analyze or Convert Mode couldn't be resolved (missing
  dependency, unknown API behavior, unclear script type) and the migration is
  incomplete as a result. Name exactly what's blocking it.

Never report "Converted" in a way that implies production-readiness in the same
breath. Only NetSuite-side testing — Sandbox first, then a controlled production
rollout — confirms that.

## Git Safety

Before modifying any file: check `git status` for uncommitted changes in scripts
about to be touched, and don't overwrite unrelated in-progress work. Keep
migration changes isolated to the script(s) being migrated — don't drag in
unrelated formatting or refactors just because the file is already open. For a
multi-script migration, suggest a dedicated branch. Never commit unless explicitly
asked to.

## Dependency Discovery

Before converting a script, search the repository for scripts/libraries it depends
on (shared helper files, other deployments of the same script, a workflow calling
into it) rather than assuming it's self-contained. If a dependency is itself
SuiteScript 1.0, state explicitly whether it also needs migration — a 1.0-style
global-function library generally can't be `require`d directly into a 2.0 AMD
module, so this is often a blocking dependency rather than something to work
around silently. This is also why Oracle's own batch-migration strategy in
`SKILL.md` puts shared libraries first: converting a dependent script before its
library is migrated just produces a script that can't load.
