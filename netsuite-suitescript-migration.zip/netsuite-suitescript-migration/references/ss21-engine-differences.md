# SuiteScript 2.1 Engine Differences to Retest

SuiteScript 2.1 runs on a different, newer JavaScript engine than 2.0/2.x. A file whose API calls are
already correct `N/*` calls (no `nlapi*`/`nlobj*` left) can still behave differently once it actually
runs as 2.1, purely because of engine differences — none of this is caught by static validation. Every
item below is either sourced or explicitly marked UNVERIFIED. Add the UNVERIFIED items as Sandbox test
cases (`sandbox-test-checklist.md`) rather than asserting an outcome.

## 1. Strict mode — undeclared variables throw

2.1 code runs in strict mode. Assigning to an undeclared variable (`foo = 1;` with no `var`/`let`/`const`
anywhere) throws `ReferenceError` in strict mode instead of silently creating a global, which 2.0's
non-strict engine allowed. This matters most for code translated from 1.0 that relied on an accidental
global (e.g. a loop variable reused across functions without declaration, or a typo'd variable name that
"worked" because it silently created a new global each time).

**What to do:** Before finalizing a 2.1 conversion, scan for any bare assignment with no matching
declaration in scope and fix it — this is a real runtime crash risk, not a style issue.

**Source:** NetSuite Help Center, "Transitioning to SuiteScript 2.1" — strict-mode behavior is called out
there as a specific 2.0→2.1 risk. Confirm the exact phrasing/scope in your Help Center, since this
session could not fetch that page directly.

## 2. `Date` parsing differences — UNVERIFIED

Different JS engine versions have historically differed in how permissively they parse non-ISO date
strings passed to `new Date(string)` (e.g. ambiguous `MM/DD/YYYY` vs `DD/MM/YYYY` strings, or strings with
unusual separators). This session could not confirm a documented behavioral difference specifically
between the 2.0 and 2.1 engines for `Date` parsing.

**What to do:** UNVERIFIED — confirm in the Help Center or empirically. Treat any code that builds a
`Date` from a raw string (rather than via `N/format`'s `format.parse()`, which is NetSuite's documented,
locale-aware path) as a risk regardless of version, and prefer `N/format` over raw `Date` string parsing
in new/converted code either way.

## 3. String/number coercion edge cases — UNVERIFIED

Loose (`==`) comparisons and implicit string/number coercion (e.g. `'' + someNumber`, `someString * 1`)
are governed by the ECMAScript spec, which both 2.0's and 2.1's engines should implement consistently for
ordinary cases. No specific 2.0→2.1 coercion regression is documented in what this session could confirm.

**What to do:** UNVERIFIED as a 2.0→2.1-specific risk. The more actionable guidance is independent of
engine version: prefer `===`/`!==` and explicit `Number()`/`String()` conversion over relying on coercion,
especially right after a field value crosses from the typed values `getValue()` returns (see
`corrections.md` #4) into string- or number-only logic carried over from 1.0.

## 4. Object property enumeration order — UNVERIFIED

Modern JS engines enumerate integer-like keys first (in ascending order) and then string keys in
insertion order — this has been the spec-defined behavior since ES2015 and should not differ between a
2.0-era and 2.1-era engine. No specific regression is documented in what this session could confirm.

**What to do:** UNVERIFIED as a 2.0→2.1-specific risk. Flag it anyway if a converted script's logic
actually depends on `for...in` or `Object.keys()` enumeration order (it shouldn't, but 1.0-era code
sometimes does) — that's fragile regardless of SuiteScript version and worth fixing on sight.

## 5. Error message text — UNVERIFIED

If any converted code does string-matching on an exception's `.message` (rather than `.name` or a
`SuiteScriptError`'s typed properties) to decide what to do, the exact wording of built-in or
platform-thrown error messages could differ between engine versions, silently breaking that matching
logic.

**What to do:** UNVERIFIED whether any specific message text actually changed between 2.0 and 2.1. The
safe rule either way: never branch on exact error-message text; branch on `e.name`,
`e.type`/`e.id` properties, or a `SuiteScriptError`'s documented fields instead (see `breaking-changes.md`
#9 / `corrections.md` for the 1.0→2.x error-object mapping). If a converted script is found doing
message-text matching, flag it as a pre-existing fragility regardless of version, and add it as a
required Sandbox test case.

---

**Reminder:** nothing in this file substitutes for Sandbox testing. "Engine difference" risks are exactly
the category static validation cannot see — they only show up by actually running the converted script.
