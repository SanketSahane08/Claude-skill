# Sandbox Test Checklist

Static validation (`scripts/validate-migration.js`, manual diff review) catches mechanical mistakes. It
cannot confirm behavior parity. Nothing in this skill's output should be described as "tested" or
"validated" until these steps actually ran in a NetSuite Sandbox account. See the completion-language
rule in `SKILL.md`.

## 0. Baseline first

Before testing the converted script, capture the **original SS1.0 script's behavior** on the same test
data: expected output, logs, resulting field values, error behavior. Without this baseline, "the
converted script works" is unfalsifiable — you have nothing to compare it to. Do this even if the
original script is already gone from production; reconstruct expected behavior from its logic, logs, or
prior run history if you must.

## 1. Data shape coverage

- Empty record (no lines, blank optional fields)
- Null/missing values on every field the script reads
- Zero-line and many-line sublists (including right at any batch-size or governance threshold the script
  checks)
- Record at the maximum field lengths/sublist line counts your account allows, if the script's logic is
  sensitive to size

## 2. Every trigger type / event the script responds to

For a User Event or Client Script, run **every** entry point it defines (not just the one you changed
most) — `beforeLoad`/`beforeSubmit`/`afterSubmit`, or `pageInit`/`fieldChanged`/`saveRecord`/etc. — since
a conversion bug in one entry point rarely shows up by exercising a different one.

## 3. Every execution context

UI, CSV import, copy, web services/RESTlet, workflow, scheduled, bundle install, user interface vs.
background — `context.type`/`runtime.executionContext` branches that behave differently per context need
a pass per context actually exercised.

## 4. Restricted roles

Run as a role with reduced permissions, not just Administrator — field-level access, record permissions,
and search visibility can all change which code paths execute and whether governance-bearing calls
succeed at all.

## 5. Subsidiaries / currencies / locales / date formats / time zones

If the account is multi-subsidiary or multi-currency, or the script does any date/time or currency
formatting, test under at least one non-default subsidiary, currency, locale, date format, and time zone
— this is exactly where typed-value and `N/format` behavior (see `corrections.md` #4, 2.x's typed
`getValue()`) most commonly diverges from 1.0's string-based behavior.

## 6. Error paths

Deliberately trigger every caught error path (invalid input, a lookup that returns nothing, a record
that fails to save) and confirm the error handling behaves the same way it did in 1.0 — not just that it
"doesn't crash." See `corrections.md` #2 for null-vs-empty-array search results as a specific case to
exercise here.

## 7. Recursion / re-entrancy (User Events)

If the script's `afterSubmit`/`beforeSubmit` itself modifies and re-saves the record, confirm it does not
recursively re-trigger itself (or confirm it intentionally does, exactly as the original did) —
submit-flag/recursion-guard logic is easy to lose or duplicate during conversion.

## 8. Large-volume run (Scheduled / Map-Reduce / Mass Update)

Run against a realistically large data set, not just a handful of test records, and specifically force
the low-governance/reschedule path (see `corrections.md` #10) to confirm the chosen architecture
(`task.create()` reschedule, or Map/Reduce) actually recovers correctly instead of losing or
double-processing records.

## 9. Per-script-type cases

- **User Event:** all three entry points, both UI and non-UI contexts (CSV import, web services), a
  record edited by a role without access to a field the script reads/writes.
- **Client Script:** every bound button / inline handler found during conversion (see `corrections.md`
  #9) actually fires in the browser, not just that the module loads without a console error.
- **Suitelet:** both GET and POST paths, an unauthenticated/external-facing request if the deployment
  allows it, and that any form state surviving a POST round-trip still works.
- **Scheduled:** the reschedule-on-low-governance path (#8 above), and both `SCHEDULED` and `ON_DEMAND`
  (or other applicable) execution contexts.
- **RESTlet:** all HTTP verbs it implements, with both valid and malformed request bodies/params.
- **Mass Update:** running against the actual saved search/criteria it's deployed against, not a hand-
  picked record list, since criteria mismatches are a common deployment-time (not code-time) bug.
- **Workflow Action:** triggered from the actual workflow state transition, not called in isolation —
  confirm `context.newRecord`/`context.oldRecord` and any workflow field values look as expected.
- **Portlet:** actually rendered on a dashboard, with the parameters a real dashboard passes, not just a
  standalone unit-style check of `render()`'s return value.
