# Library / Multi-Entry-Point Files

Not every SS1.0 file is a single deployable script. A large share of real-world SS1.0 code is library
files: a bag of functions using `nlapi*`/`nlobj*` APIs that are either (a) included into other scripts
via `nlapiIncludeScript`/the Script record's "Library Scripts" field, or (b) a single physical file where
several *different* NetSuite Script records each point at one function in it as their entry point (one
`beforeLoad`-shaped function for a User Event record, one `suitelet`-shaped function for a Suitelet
record, a `fieldChanged`-shaped function for a Client Script record, etc. — all coexisting in the same
file). Neither case is a parsing error or an ambiguity to block on. The API replacement work is identical
either way and is never gated on resolving the file's deployment architecture.

## Shape A — pure helper library (no entry points)

Every function is a utility called by *other* scripts (via `nlapiIncludeScript` in SS1.0, or a `define()`
dependency in 2.x); nothing in the file matches a script-type entry-point signature on its own.

Handling: convert to a single `define()` module with no `@NScriptType`, exposing every converted
function in the return object, API calls replaced in place:

```javascript
define(['N/record'], function (record) {
    function myHelper() { /* ... */ }
    return { myHelper: myHelper };
});
```

The validator (`scripts/validate-migration.js`) treats a file with no `@NScriptType` and no exported name
matching a known entry-point as this shape — a Low-severity informational note, not an error.

## Shape B — bundle of entry points for multiple different Script records

Several functions in the file each match a *different* script type's entry-point naming convention (for
example one `beforeLoad(type, form)`-shaped function, one `suitelet(request, response)`-shaped function,
and one `fieldChanged(type, name)`-shaped function, all in the same file) — because in SS1.0 it was normal
for several unrelated NetSuite Script records to each be pointed at one function inside a shared physical
file. This is **not** "mixed SS1.0/SS2.x code" (that error case is about one script having both `nlapi*`
and `N/*` calls at once) and it is **not** an ambiguity to flag under Do Not Guess — it's a known, normal
SS1.0 authoring pattern.

Default handling, without waiting on an architecture decision:

1. Still run the full API conversion pass (every `nlapi*`/`nlobj*` → the confirmed target version's
   `N/*` equivalent, breaking changes applied, ES5 or 2.1 style per the confirmed target) across the
   *entire* file, function by function, exactly as for a single-script file.
2. Keep every function in the file, under its original name, with its logic otherwise untouched — don't
   merge, dedupe, or drop any of them.
3. Because SS2.0/2.1 require exactly one `@NScriptType` and one `define()` return object per deployed
   script, name the fact that this file maps to N separate future Script records and will eventually
   need N separate files (one per entry-point function, each with its own `@NScriptType`/`@NApiVersion`
   header and `define()`/return shape), sharing any pure-helper functions (like a shared formatter) via a
   common library module (Shape A). Offer this as the next step rather than performing it automatically
   — the user may just want the API calls modernized first and the file split later, or may want the
   split now; don't assume either way.
4. Flag any function in the file whose entry-point shape doesn't clearly map to a known script type (see
   `script-type-changes.md`) per Do Not Guess, rather than guessing its deployment context.

## If script type cannot be detected at all

```
Unable to detect a single script type. The file may be:
- A utility/helper module (no entry points) — Shape A above
- A library file loaded via nlapiIncludeScript — Shape A above
- A standalone function not deployed as a Script record
- A bundle of entry points for several different Script records living in
  one physical file (normal in SS1.0) — Shape B above

Neither shape blocks conversion — every nlapi*/nlobj* call in the file still
gets replaced with the confirmed target version's N/* equivalent; only the
file-splitting/deployment-structure question is optional and separate from
the API conversion itself.
```
