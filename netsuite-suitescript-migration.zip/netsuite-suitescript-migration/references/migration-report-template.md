# Per-Script Migration Report Template

Produce one of these for every migrated script (or, for a Shape B multi-entry-point file, one covering
the whole file plus a note on the eventual per-entry-point split). Fill every field — write "None" or
"N/A" explicitly rather than omitting a field with nothing to say.

```markdown
## Migration Report: [filename]

- **Script:** [script name / purpose, one line]
- **Original File:** [path to the SS1.0 source]
- **New File:** [path to the converted file — same path if side-by-side mode kept the original elsewhere]
- **Script Type:** [@NScriptType] — confirmed via: [@NScriptType annotation present in source /
  entry-point signature match / SDF Object XML / user-provided — state which]
- **Original Version:** [SS1.0 / SS2.0 / SS2.x, as detected]
- **Target Version:** [2.1 (default) / 2.0 (explicit override)] — confirmed via: [user request / existing
  repo @NApiVersion convention / explicit override request]

### Migration Summary
[2-4 sentences: what this script does, and what changed mechanically to get it to the target version.]

### 1.0 APIs Converted
| SS1.0 API | SS2.x Equivalent | Count |
|---|---|---|
| ... | ... | ... |

### Modules Added
[List of N/* modules added to the define() dependency array, and why each is needed.]

### Entry Points Converted
| SS1.0 Entry Point | SS2.x Entry Point |
|---|---|
| ... | ... |

### Records Used
[Record types the script loads/creates/submits/deletes.]

### Searches Used
[Saved searches or ad hoc searches the script runs — include search IDs where known.]

### Dependencies
[Other scripts/libraries this one calls into or is called from — nlapiIncludeScript targets, shared
library modules, cross-file function references found during analysis.]

### Business Logic Preserved
[Explicit statement that conditions, validations, filters, field mappings, and execution timing were not
changed as a side effect of the API conversion — or, if something had to change (e.g. a search null-check
rewrite per corrections.md #2), name exactly what changed and why it was necessary rather than optional.]

### Potential Risks
[Anything from corrections.md, ss21-engine-differences.md, or general judgment that could change behavior
and isn't purely mechanical — e.g. record-mode choice, typed-value comparisons, governance budget shifts.]

### Governance Considerations
[Governance-bearing calls and their approximate unit cost; any loop containing a governance-bearing call,
flagged per the validator's loop-governance check; whether the original script's governance profile is
materially different post-conversion.]

### Required Changes vs. Optional Improvements (Not Applied)
- **Required (applied):** [list]
- **Optional (recommended, not applied):** [list — e.g. "switch Scheduled Script to Map/Reduce",
  "switch to search.each()/runPaged() instead of the preserved 1,000-row getRange() cap"]

### Open Issues / MIGRATION-REVIEW Markers
[Every `// MIGRATION-REVIEW: <reason>` left in the converted file, with its line number and reason,
copied here so none of them get lost in the diff.]

### Metadata (SDF / Script Record) Changes Needed
[Script record XML changes: scriptfile path, removed entry-point-function-name fields, any deployment
XML the user needs to update — see `netsuite-sdf-leading-practices` if installed, otherwise list the
specific XML elements needing changes and ask the user to apply them.]

### Static Validation Performed
[Command(s) run, e.g. `node scripts/validate-migration.js --target 2.1 path/to/file.js
--original path/to/original.js`, and a summary of the result — pass/fail and counts by severity.]

### Testing Required
[What manual/Sandbox testing this script still needs before it can be considered done — point to the
relevant parts of `sandbox-test-checklist.md`.]

### Recommended Sandbox Test Cases
[Concrete list, specific to this script — not just a link to the generic checklist.]

### Status
[One of: **Converted** / **Needs review** / **Requires testing** / **Blocked** — see
`business-logic-preservation.md` for exactly what each status means.]
```
