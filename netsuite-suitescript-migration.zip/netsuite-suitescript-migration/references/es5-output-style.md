# ES5 Output Style (SuiteScript 2.0 Target)

Every code example elsewhere in this skill — `SKILL.md`'s "Core Functionality,"
"Common Conversion Patterns," and all of `references/*.md` — is written in
SuiteScript 2.1 style: arrow functions, `const`/`let`, template literals,
destructuring. That's inherited from the upstream version of this skill, which
targeted 2.1. **This copy of the skill targets literal SuiteScript 2.0, which does
not support that syntax.** The good news: the `N/*` API surface itself — module
names, method names, options-object parameter shapes, context objects, 0-based
sublist indexing, enums — is identical between 2.0 and 2.1. Only the JavaScript
language envelope around those calls needs to change. This file is the translation
table. Read it every time Convert Mode is about to produce final code, not just once.

## Translation Table

| 2.1-style (what the examples show) | 2.0-style (what to actually write) | Notes |
|---|---|---|
| `define([...], (record, search) => {...})` | `define([...], function (record, search) {...})` | The module factory is always a `function` expression, never an arrow function. |
| `const x = ...` / `let x = ...` | `var x = ...` | No block scoping in ES5 — watch for `var` hoisting changing behavior in loops with closures (see "Closures in Loops" below). |
| `` `Customer ${id} processed` `` | `'Customer ' + id + ' processed'` | Template literals → string concatenation. Watch for multi-line template literals — they need explicit `'\n'` or string concatenation across lines. |
| `const { fieldId, value } = params;` | `var fieldId = params.fieldId;` <br> `var value = params.value;` | Destructuring → explicit property access, one line per field. |
| `const [first, second] = arr;` | `var first = arr[0];` <br> `var second = arr[1];` | Array destructuring → explicit indexing. |
| `function f(a, b = 10) {...}` | `function f(a, b) {` <br> `  b = (b === undefined) ? 10 : b;` <br> `...}` | Default parameters → explicit guard at the top of the function body. |
| `function f(...args) {...}` | `function f() {` <br> `  var args = Array.prototype.slice.call(arguments);` <br> `...}` | Rest parameters → `arguments` object sliced into a real array. |
| `fn(...argsArray)` | `fn.apply(null, argsArray)` | Spread into a call → `.apply()`. |
| `const merged = [...a, ...b];` | `var merged = a.concat(b);` | Array spread → `.concat()`. |
| `const merged = { ...a, ...b };` | Build manually: copy `a`'s own keys onto a new object, then `b`'s, or use a small manual-merge helper. | Object spread has no ES5 shortcut — don't reach for `Object.assign` either unless you've confirmed it's available in the target account's engine; a manual loop is the safe default. |
| `for (const item of list) {...}` | `for (var i = 0; i < list.length; i++) { var item = list[i]; ... }` | `for...of` → classic indexed loop. (`list.forEach(function (item) {...})` is also fine and is ES5.) |
| `class Foo { constructor(x) { this.x = x; } bar() {...} }` | `function Foo(x) { this.x = x; }` <br> `Foo.prototype.bar = function () {...};` | Classes → constructor function + `.prototype` methods. |
| `async function f() { const r = await g(); }` | Not needed — see "On async/await" below | SuiteScript 2.0's `N/record`, `N/search`, etc. are synchronous APIs; there's usually nothing to `await` in the first place. |
| `a?.b?.c` | `a && a.b && a.b.c` | No optional chaining in ES5. |
| `a ?? b` | `(a === null || a === undefined) ? b : a` | No nullish coalescing in ES5. `a || b` is close but wrong if `a` is `0`, `''`, or `false` and that's a valid value — use the explicit null/undefined check when that distinction matters. |
| `arr.includes(x)` | `arr.indexOf(x) !== -1` | `Array.prototype.includes` is an ES2016 addition; use `indexOf`. |

## On async/await

SuiteScript 2.0 and 2.1 record/search/etc. APIs are synchronous — `record.load()`
returns the loaded record directly, it doesn't return a Promise. The only place
`async`/`await` legitimately shows up in a 2.1-style example is usually a
stylistic choice by whoever wrote the example, not a functional requirement. When
you see it in a reference example, just drop it and call the API directly,
synchronously, as ES5 code would.

## Closures in Loops: the one real behavioral risk in var→const translation

This is the one spot where "just swap `const`/`let` for `var`" can silently change
behavior, so check for it explicitly rather than doing a blind find-and-replace:

```javascript
// 2.1-style — each callback captures its OWN i (block-scoped)
for (let i = 0; i < lineCount; i++) {
  someAsyncOrDeferredThing(() => console.log(i));
}

// Naive ES5 translation — BROKEN: every callback shares the SAME i,
// which will be lineCount by the time any callback actually runs
for (var i = 0; i < lineCount; i++) {
  someAsyncOrDeferredThing(function () { console.log(i); });
}

// Correct ES5 translation — capture i per-iteration via an IIFE or a helper
for (var i = 0; i < lineCount; i++) {
  (function (capturedI) {
    someAsyncOrDeferredThing(function () { console.log(capturedI); });
  })(i);
}
```

In practice, most SuiteScript sublist/search loops don't defer a callback past the
loop's own synchronous execution (they call `getSublistValue`, do something, move
on), so this usually doesn't bite — but check for it specifically whenever a loop
body captures the loop variable inside a function that will run later (a
`.each()` callback stored for later, a scheduled task callback, etc.) rather than
assuming the swap is always safe.

## Worked Example: Pattern 14 (User Event) Translated to ES5/2.0

This is the direct ES5/2.0 translation of `SKILL.md`'s "Pattern 14: User Event
Entry Point Migration" example. The 2.1-style version in `SKILL.md` is correct for
illustrating the API mapping (`nlapiGetNewRecord()` → `context.newRecord`, string
type → `context.UserEventType` enum) — this is what actually gets written to disk
for a 2.0 target:

```javascript
/**
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 */
define(['N/log'], function (log) {

    function beforeLoad(context) {
        if (context.type === context.UserEventType.VIEW) return;
        context.form.addButton({
            id: 'custpage_btn',
            label: 'My Button',
            functionName: 'myFunction'
        });
    }

    function beforeSubmit(context) {
        if (context.type === context.UserEventType.CREATE) {
            context.newRecord.setValue({ fieldId: 'memo', value: 'Created' });
        }
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit
    };
});
```

Differences from the 2.1-style version in `SKILL.md`: `define`'s factory is a
`function` expression, not an arrow function; entry points are declared as
`function beforeLoad(context) {...}` statements rather than `const beforeLoad =
(context) => {...}` assignments; the `return` object spells out
`beforeLoad: beforeLoad` rather than relying on ES6's shorthand property syntax.
Everything else — the context object shape, the enum usage, the method calls — is
identical, because none of that is 2.1-specific.
