# Corrections to Oracle's Reference Files

This file exists because `api-mapping.json`, `object-mapping.json`, `breaking-changes.md`,
`conversion-guide.md`, `script-type-changes.md`, and `unmapped-apis.md` are kept **byte-identical** to
Oracle's originals (oracle/netsuite-suitecloud-sdk, `packages/agent-skills/netsuite-suitescript-upgrade`)
so upstream updates stay diffable. Any correction to those files' content goes here instead of editing
them directly.

**Rule: if this file conflicts with any of the six files above, or with an example in `SKILL.md` itself,
this file wins.** Do not silently resolve the conflict in the other direction.

Each entry: what Oracle's file says → what's actually true / what to do → source, or an explicit
UNVERIFIED flag if a session couldn't confirm it against the NetSuite Help Center.

---

## 1. `nlapiSearchRecord` → `.each()` result-count ceiling

**api-mapping.json says:** `.each()` iteration "No 1000-result limit" (implying it fully replaces
`nlapiSearchRecord`'s 1,000-row cap with no cap at all).

**Actually true:** `search.create(...).run().each()` is itself capped — NetSuite's own help text (quoted
in this skill's own `SKILL.md`/`script-type-changes.md` governance notes) puts the `.each()` ceiling at
4,000 results. SuiteScript 1.0's `nlapiSearchRecord` returned at most 1,000 rows per call. Converting a
1.0 search straight to `.each()` silently changes behavior from "capped at 1,000" to "capped at 4,000" —
not unlimited, and not the same cap either direction.

**What to do:** Don't assume "switch to `.each()`" is a safe drop-in replacement for a 1.0 search that
relied on (or was unaware of) the 1,000-row cap. Preserve the original row-count behavior by default:
use `getRange({ start: 0, end: 1000 })` to match the 1.0 ceiling exactly. Offer "switch to `.each()` /
`search.runPaged()` to see all matching rows" only as a clearly separate, optional improvement — never
silently fold it into the conversion.

**Source:** NetSuite Help Center, SuiteScript 2.x governance/search documentation (4,000-result `.each()`
cap); SuiteScript 1.0 `nlapiSearchRecord` documentation (1,000-row cap). Exact current wording should be
confirmed against the Help Center for the account in question, since Oracle has adjusted iteration limits
across releases.

---

## 2. Search "no results" handling: `null` vs `[]`

**Oracle's files generally show search code without restating this,** and it's easy to carry a 1.0-style
null check forward unexamined.

**Actually true:** SuiteScript 1.0's `nlapiSearchRecord` returns `null` when a search matches nothing.
SuiteScript 2.x's `search.create(...).run().getRange(...)` and `.each()` return an empty array / iterate
zero times — never `null`.

**What to do:** Never drop a 1.0 "no results" branch (e.g. a create-if-not-found pattern) during
conversion just because the null check "looks wrong" for 2.x. Rewrite the condition, don't delete it:

```javascript
// SS1.0
var results = nlapiSearchRecord(...);
if (!results) { /* create new */ }

// SS2.x — rewritten, not removed
var results = searchObj.run().getRange({ start: 0, end: 1 });
if (!results || results.length === 0) { /* create new */ }
```

**Source:** NetSuite Help Center, `N/search` module — `Search.run()` / `ResultSet.getRange()` return
types.

---

## 3. Never copy a custom ID out of an example

**Oracle's `SKILL.md` Pattern 15** (and other inline examples throughout the skill) use a generic field
ID, `custbody_status`, purely for illustration. It is not a real field ID for your account.

**What to do:** Never carry an ID string (`custbody_*`, `custrecord_*`, `customscript_*`, etc.) from an
example in this skill's reference files or SKILL.md into a real converted script. Every custom ID in
converted output must come from the original SS1.0 source file being converted, character-for-character
— never invented, never copied from a sample. If a required ID can't be found in the source file or the
repo, that's a Do-Not-Guess case: flag it, don't substitute an example ID.

**Source:** internal — this is a process rule, not a NetSuite behavior claim.

---

## 4. Typed field values from `getValue()` / `getFieldValue()`

**Oracle's `api-mapping.json` entry for `nlapiGetFieldValue` lists no breaking changes** for the
value-type mapping itself.

**Actually true:** `record.getValue()` (and `currentRecord.getValue()`) return **typed** values:
booleans for checkbox fields (not the `'T'`/`'F'` strings 1.0 returned), `Date` objects for date/datetime
fields (not formatted strings), and `Number` for numeric/currency/percent fields (not strings). 1.0's
`nlapiGetFieldValue` always returned a string, so any 1.0 code doing string comparison/concatenation on a
checkbox, date, or number field will behave differently once typed values flow through unchanged logic.

**What to do:**
- Checkbox fields: compare the converted value with `=== true` / `=== false`, not `=== 'T'` / `=== 'F'`.
- Date/datetime fields: use the `Date` object directly, or `format.format()` if a formatted string is
  genuinely needed downstream.
- If the original 1.0 code needed the *display* string rather than the typed value (for example to put
  it into a log message or a non-field UI string exactly as the user would see it), use `getText()` /
  `currentRecord.getText()` or `N/format`, not a manual type coercion.

**Source:** NetSuite Help Center, `N/record` module — `Record.getValue()` return types by field type.

---

## 5. Record mode (standard vs. dynamic) — partially UNVERIFIED

**Oracle's `breaking-changes.md` (#8, "Dynamic vs Standard Record Mode") and `SKILL.md` Pattern 6**
suggest that SS1.0 body-field sourcing "fires automatically" by default, and show the 2.x conversion of
that pattern using `isDynamic: true`.

**Confirmed:** On `nlapiSubmitRecord(record, doSourcing, ignoreMandatoryFields)` and `nlapiSubmitField`,
the `doSourcing` parameter **defaults to `false`** — sourcing does *not* happen automatically on submit
unless explicitly requested. In SS2.x, standard mode (`isDynamic: false`) is the default for
`record.load()`/`record.create()`, and is faster with no automatic sourcing; dynamic mode
(`isDynamic: true`) is required for current-line sublist APIs (`selectNewLine`, `selectLine`,
`setCurrentSublistValue`, `commitLine`) and mirrors UI-style sourcing behavior.

**UNVERIFIED:** Whether SS1.0's *implicit* record behavior for line-item manipulation
(`selectNewLineItem`/`setCurrentLineItemValue`/`commitLineItem`, used without an explicit `recordmode`
option) is behaviorally equivalent to SS2.x's `isDynamic: true` in every case, or whether some SS1.0
scripts relied on standard-mode-like behavior while still calling those APIs. This isn't confirmed either
way in this session — confirm against the NetSuite Help Center's SuiteScript 1.0 Record APIs
documentation (or empirically, in Sandbox) before assuming a blanket mapping.

**What to do:** Don't change a script's record mode as a side effect of conversion. Default rule: if the
1.0 source used `selectNewLineItem`/`setCurrentLineItemValue`/`commitLineItem` (current-line sublist
APIs), the 2.x conversion needs `isDynamic: true` (or an explicit standard-mode rewrite using
`insertLine`/`setSublistValue`/`removeLine` instead) — state which one was chosen in the migration report,
and always add it as a required Sandbox test case per `sandbox-test-checklist.md`, since this is exactly
the kind of change static validation cannot confirm.

**Source:** NetSuite Help Center, SuiteScript 1.0 Record APIs (`doSourcing` default) — confirmed;
SuiteScript 1.0 vs 2.x implicit-mode equivalence — UNVERIFIED, confirm in Help Center before relying on
it.

---

## 6. `nlapiRequestURL` → `N/http` or `N/https`

**Oracle's `SKILL.md` module table maps `nlapiRequestURL`/`nlapiRequestURLWithCredentials` to**
`N/http` *or* `N/https`, without stating which to pick.

**Actually true:** `N/https` is required for any `https://` target URL and for sending credentials — it
encapsulates `N/http`'s functionality but does not allow plain HTTP. `N/http` is for `http://` targets
only. The target endpoint's certificate must be issued by a CA NetSuite trusts (no self-signed certs).

**What to do:** Pick the module from the URL's actual scheme in the original 1.0 call (or its config),
not by guessing — `https://` → `N/https`, `http://` → `N/http`. Never move a credential value into a
plain-text request parameter, header, or URL; use `N/https`'s secure credential-field support (a handle
to a stored credential, not the literal secret) wherever the 1.0 code had `nlapiRequestURLWithCredentials`.

**Source:** NetSuite Help Center, `N/https` module documentation.

---

## 7. Governance units — `nlapiLookupField` / `search.lookupFields`

**Oracle's `breaking-changes.md:607` states 5 units for both** `nlapiLookupField` and
`search.lookupFields`.

**Likely incorrect for `search.lookupFields`:** Independent surveys of NetSuite's own governance-unit
tables (not Oracle's skill file) report `search.lookupFields` at **1 unit**, not 5 — one of the cheaper
2.x calls specifically because it avoids a full record load.

**What to do:** Don't rely on either number for actual governance budgeting in a long-running script.
**UNVERIFIED — confirm the current exact value in your account's own Help Center → Governance Units
table** before using it to size batches or set `getRemainingUsage()` thresholds; Oracle has revised these
tables across releases, and the account-specific table is authoritative over any skill file.

**Source:** Secondary survey (not Oracle's own current Help Center table) reporting 1 unit; flagged
UNVERIFIED against the primary source.

---

## 8. `ignoreFieldChange` is inverted from `firefieldchanged` — same boolean, opposite meaning

**`conversion-guide.md`'s Pattern 4 example** carries a comment on this that reads as more confusing than
clarifying (it can't be edited there since that file must stay byte-identical to Oracle's).

**Clear statement of the actual rule:** SS1.0's `nlapiSetFieldValue(name, value, firefieldchanged, sync)`
— `firefieldchanged: true` means **fire** the field-change event (this was also the 1.0 default when the
parameter was omitted). SS2.x's `setValue({ fieldId, value, ignoreFieldChange })` —
`ignoreFieldChange: false` means **don't ignore** the event, i.e. still fire it — the same net behavior,
opposite-sense boolean. So a straight value carry-over is wrong:

| 1.0 `firefieldchanged` | Meaning | 2.x `ignoreFieldChange` | Meaning |
|---|---|---|---|
| `true` (or omitted) | fire the event | `false` (or omitted) | don't ignore → fires |
| `false` | suppress the event | `true` | ignore → suppressed |

**What to do:** Convert `firefieldchanged: true` → `ignoreFieldChange: false` (or omit it; `false` is the
2.x default too) and `firefieldchanged: false` → `ignoreFieldChange: true`. Never copy the literal boolean
across unchanged.

**Source:** NetSuite Help Center, `N/currentRecord` and `N/record` `setValue()` options — `ignoreFieldChange`;
SuiteScript 1.0 `nlapiSetFieldValue` parameter documentation — `firefieldchanged`.

---

## 9. Client Script "global" functions aren't global in 2.x

**Not explicitly called out anywhere in Oracle's files.**

**Actually true:** In SS1.0, any function declared at the top level of a Client Script file was reachable
from anywhere NetSuite needed to call it by name — including button `functionName` bindings created via
`form.addButton()`, inline `onclick` HTML strings on custom fields/forms, and other form-level bindings
set up server-side (e.g. in a paired User Event). In SS2.x's `define()` module pattern, nothing inside the
factory function is global; only names in the `return { ... }` object are reachable by NetSuite's own
entry-point dispatch, and that still does **not** cover arbitrary `onclick="myFunction()"` HTML strings
or page-level `functionName` button bindings — a browser looking for `myFunction` in `window` scope will
not find it, because it only exists inside the module closure.

**What to do:** When converting a Client Script, search the file and any linked User Event/Suitelet code
for button bindings and inline `onclick`-style strings that reference a function by name. For each one
found, either expose that function on `window` explicitly (e.g.
`window.myFunction = myFunction;` immediately after the `define()` callback, outside the factory, if the
calling convention truly requires a global) or — the generally preferred approach — add it to the
`return { ... }` object under its original name so NetSuite's own binding mechanism picks it up, and flag
any case where neither works cleanly (e.g. a raw HTML `onclick`) for the user to confirm before relying on
the `window` workaround, since it reintroduces a global.

**Source:** internal — based on how `define()` module scoping works; not a documented NetSuite breaking
change, but a direct consequence of AMD module scoping that Oracle's files don't call out. Confirm the
specific binding mechanism (button vs. inline HTML vs. form field script) in Sandbox for each converted
Client Script.

---

## 10. `nlapiYieldScript` / `nlapiSetRecoveryPoint` — preserve architecture by default

**Oracle's `SKILL.md` Pattern 15 presents Map/Reduce as "the" SS2.1 answer** for any Scheduled Script that
used recovery points.

**What to do (restated explicitly so it survives any future trimming of SKILL.md):** The behavior- and
architecture-preserving default is to keep the script as a `ScheduledScript`, drop the
recovery-point-exact resume behavior (there is no direct equivalent), and reschedule via `task.create()`
when governance runs low — same shape as any other Scheduled Script migration, no architecture change.
Converting to `MapReduceScript` is a separate, larger, optional recommendation to offer *alongside* the
default conversion, never silently substituted for it. Make the choice explicit in the migration report,
and treat the governance-exhaustion/reschedule path as a required Sandbox test case (large input set,
forced low-governance condition) either way.

**Source:** NetSuite Help Center — `nlapiSetRecoveryPoint`/`nlapiYieldScript` have no direct SS2.x
equivalent (confirmed by their absence from the current `N/*` API surface); the "which architecture to
pick" rule itself is a project policy decision, not a NetSuite behavior claim.
