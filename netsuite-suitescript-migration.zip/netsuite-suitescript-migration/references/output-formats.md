# Output Format Templates

Full markdown templates for each mode's output. `SKILL.md` describes each mode's process briefly and
links here for the exact shape to produce.

## Analyze Mode

```markdown
## Migration Analysis: [filename]

### Script Overview
- **Detected Version**: SuiteScript 1.0
- **Script Type**: [UserEventScript / ClientScript / Suitelet / etc., or **Library/Module (no entry
  points)** per Shape A in `library-and-multi-entry-files.md` — don't force a file with no matching
  entry-point signature into one of the other categories]
- **Line Count**: [N]
- **Entry Points**: [list of detected entry point functions, or **None — library/helper module** if
  Shape A applies]

### SS1.0 API Usage Summary

#### nlapi* Function Calls ([total] calls, [unique] unique)

| Function | Count | SS2.x Module | Status |
|----------|-------|-------------|--------|
| nlapiLoadRecord | 3 | N/record | Mapped |
| nlapiSearchRecord | 2 | N/search | Mapped |
| nlapiAddDays | 1 | — | Unmapped (use native JS) |

#### nlobj* Object Usage ([total] objects)

| Object | Count | SS2.x Class |
|--------|-------|-------------|
| nlobjSearchFilter | 4 | search.createFilter / filter array |
| nlobjSearchColumn | 3 | search.createColumn |

### Required N/* Modules

| Module | Import Name | Reason |
|--------|-------------|--------|
| N/record | record | nlapiLoadRecord, nlapiSubmitRecord |
| N/search | search | nlapiSearchRecord, nlapiLookupField |
| N/log | log | nlapiLogExecution |

### Breaking Changes Affecting This Script

| # | Change | Impact | Severity |
|---|--------|--------|----------|
| 1 | 1-based → 0-based sublist indexing | 3 loop constructs need updating | High |
| 2 | Positional params → options objects | 12 function calls | Medium |
| 3 | String type checks → enum values | 2 event type comparisons | Low |

### Unmapped APIs Found

| Function | Workaround |
|----------|------------|
| nlapiAddDays | Use native JavaScript Date methods |

### Migration Complexity

| Factor | Score |
|--------|-------|
| Line count | 2 (Medium) |
| nlapi calls | 2 (Medium) |
| Subrecord usage | 1 (None) |
| Date/time ops | 2 (Body fields) |
| Recovery points | 1 (None) |
| Custom modules | 1 (None) |
| Sublist ops | 3 (Dynamic) |
| **Total** | **12 / 21** |

**Complexity Rating: Medium**

### Migration Checklist

- [ ] Set up SS2.x file with confirmed @NApiVersion and @NScriptType
- [ ] Create define() wrapper with required modules
- [ ] Convert nlapi* calls to N/* module methods
- [ ] Convert nlobj* objects to SS2.x classes
- [ ] Fix sublist loops from 1-based to 0-based indexing
- [ ] Replace unmapped APIs with native JS / documented workarounds
- [ ] Convert entry points to context-based pattern
- [ ] Update error handling from nlobjError to try/catch
- [ ] Test in the Sandbox environment (sandbox-test-checklist.md)
- [ ] Update deployment XML (remove entry point function names)
```

## Convert Mode

```markdown
## Conversion: [filename] → SS2.x

### Converted File

(write to the agreed output path per the Output Location Mode confirmed in the approval gate)

### Deployment XML Updates

Remove entry point function name fields from the script record XML (if installed, use
`netsuite-sdf-leading-practices` to generate the full XML; otherwise list the specific elements to
change and ask the user to apply them).

### Migration Notes

| # | Line | Change | Before | After |
|---|------|--------|--------|-------|
| 1 | 1-3 | Added JSDoc tags | (none) | @NApiVersion, @NScriptType |
| 2 | 4 | AMD wrapper | Global scope | define([...]) |
| 3 | 8 | Entry point signature | function beforeLoad(type, form) | context-object pattern |
| 4 | 12 | Record access | nlapiGetNewRecord() | context.newRecord |
| 5 | 15 | Field get | rec.getFieldValue('entity') | rec.getValue({ fieldId: 'entity' }) |

### Post-Conversion Checklist

- [ ] Review all converted API calls for correctness
- [ ] Verify 0-based indexing in all sublist loops
- [ ] Check that all required modules are in the define() array
- [ ] Run `node scripts/validate-migration.js --target <2.0|2.1> --original <ss1-file> <converted-file>`
- [ ] Fill out `migration-report-template.md` for this script
- [ ] Test in the Sandbox environment per `sandbox-test-checklist.md`
- [ ] Generate deployment XML (`netsuite-sdf-leading-practices` if installed, else list manually)
```

### Conversion with Annotations (`--annotated`)

```javascript
const rec = record.load({          // [3] nlapiLoadRecord → record.load
    type: record.Type.SALES_ORDER, // [4] String type → record.Type enum
    id: orderId,
    isDynamic: false
});

for (let i = 0; i < lineCount; i++) {  // [7] 1-based → 0-based indexing
    const qty = rec.getSublistValue({   // [8] getLineItemValue → getSublistValue
        sublistId: 'item',
        fieldId: 'quantity',
        line: i                         // [9] Was: line i+1 (1-based)
    });
}
```

## Explain Mode

**For nlapi\* functions:**

```markdown
## API Mapping: [nlapiFunction]

### SS1.0 Signature
```javascript
nlapiSearchRecord(type, id, filters, columns)
```

### SS2.x Equivalent
**Module:** `N/search`
**Method:** `search.create` + `run` / `search.load`

### Parameter Changes

| SS1.0 Param | SS2.x Param | Notes |
|------------|------------|-------|
| type | type | Same |
| id | id | Used with search.load() for saved searches |
| filters | filters | Same format, plus filter expressions |
| columns | columns | Same format, plus search.createColumn() |

### Breaking Changes
- Returns a `search.ResultSet` (iterable) instead of an `nlobjSearchResult[]` array
- Must call `.run()` to get results, then `.each()` or `.getRange()` to iterate — see
  `corrections.md` #1 for the actual result-count ceilings on each path
- `.each()` callback must return `true` to continue (stops on `false`)

### Governance
See `corrections.md` for any unit-count corrections to Oracle's numbers; confirm against your account's
own Help Center Governance Units table either way.

### Related
- See also: `nlapiCreateSearch`, `nlapiLoadSearch`
- Object: `nlobjSearch` → `search.Search`
```

**For nlobj\* objects:** same shape as above, but look up `object-mapping.json` for the class, module,
and method conversions, and highlight any method that became a property or has inverted boolean logic.

**For concepts:**

```markdown
## Migration Concept: [Concept Name]

### What Changed
[Clear explanation of the behavioral change]

### Why It Changed
[Rationale — better API design, consistency, etc.]

### SS1.0 Pattern
```javascript
[Before code]
```

### SS2.x Pattern
```javascript
[After code]
```

### Common Migration Mistake
[The most common error developers make when converting this pattern]

### Rules to Remember
1. [Rule 1]
2. [Rule 2]

### Reference
- See: `references/[relevant-file]`
```

## Validate Mode

```markdown
## Validation Report: [filename]

### Script Info
- **@NApiVersion**: 2.1 ✅
- **@NScriptType**: UserEventScript ✅
- **define() wrapper**: Present ✅
- **Return object**: Present ✅

### Issues Found ([total])

#### Critical ([count])

| # | Line | Issue | Found | Fix |
|---|------|-------|-------|-----|
| 1 | 45 | Leftover nlapi call | `nlapiLogExecution('DEBUG', ...)` | Replace with `log.debug({ title, details })` |

#### High ([count])
#### Medium ([count])
#### Low ([count])
(same table shape per severity)

### Summary
- **Critical**: [N] issues — must fix before deployment
- **High**: [N] issues — likely bugs if not fixed
- **Medium**: [N] issues — code will work but isn't idiomatic for the target
- **Low**: [N] issues — style improvements

### Validation Result: [PASS / FAIL]
[FAIL if any Critical or High issues remain]
```

Run `node scripts/validate-migration.js --target <2.0|2.1> <file>` first — it checks most of this
mechanically (see `SKILL.md`'s Validate Mode section for the full checklist). A clean run means "no
obvious mechanical mistakes," not "validated" — see `business-logic-preservation.md` and
`sandbox-test-checklist.md`.
