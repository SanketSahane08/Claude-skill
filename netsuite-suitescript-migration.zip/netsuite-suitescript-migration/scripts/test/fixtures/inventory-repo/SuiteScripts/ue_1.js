/**
 * @NApiVersion 1.0
 */
nlapiIncludeScript('SuiteScripts/shared_lib.js');

function beforeLoad(type, form, request) {
    var name = nlapiLookupField('customer', 123, 'companyname');
    nlapiLogExecution('DEBUG', 'Customer', name);
}

function beforeSubmit(type) {
    var rec = nlapiGetNewRecord();
    rec.setFieldValue('memo', 'Updated');
}

function afterSubmit(type) {
    formatHelperName(nlapiGetNewRecord());
}
