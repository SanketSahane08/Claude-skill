/**
 * @NApiVersion 1.0
 */
function formatHelperName(rec) {
    var name = rec.getFieldValue('entity');
    return nlapiEscapeXML(name);
}
