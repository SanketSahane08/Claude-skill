/**
 * @NApiVersion 1.0
 */
function scheduled(type) {
    var results = nlapiSearchRecord('salesorder', 'customsearch_pending');
    for (var i = 0; i < results.length; i++) {
        var rec = nlapiLoadRecord('salesorder', results[i].getId());
        rec.setFieldValue('status', 'processed');
        nlapiSubmitRecord(rec);

        var remaining = nlapiGetContext().getRemainingUsage();
        if (remaining < 100) {
            nlapiSetRecoveryPoint();
            nlapiYieldScript();
        }
    }
}
