/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 */
define(['N/currentRecord'], function (currentRecord) {

    function pageInit(context) {
        var rec = currentRecord.get();
        var qty = rec.getValue({ fieldId: 'quantity' });
        if (qty > 0) {
            rec.setValue({ fieldId: 'memo', value: 'Has quantity' });
        }
    }

    function fieldChanged(context) {
        var rec = currentRecord.get();
        var lineCount = rec.getLineCount({ sublistId: 'item' });
        for (var i = 0; i < lineCount; i++) {
            var val = rec.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
        }
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged
    };
});
