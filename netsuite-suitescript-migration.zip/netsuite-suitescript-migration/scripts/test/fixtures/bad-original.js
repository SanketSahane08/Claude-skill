/**
 * @NApiVersion 1.0
 */
function beforeLoad(type, form, request) {
    var count = nlapiGetLineItemCount('item');
    for (var i = 1; i <= count; i++) {
        var qty = nlapiGetLineItemValue('item', 'quantity', i);
    }
    nlapiLogExecution('DEBUG', 'beforeLoad', 'done');
}

function afterSubmit(type) {
    var rec = nlapiGetNewRecord();
    var isActive = rec.getFieldValue('custbody_old_name');
    if (isActive === 'T') {
        nlapiLogExecution('DEBUG', 'active', 'yes');
    }
}
