/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/log'], (log) => {

    const beforeSubmit = (context) => {
        const rec = context.newRecord;
        const entity = rec.getValue({ fieldId: 'entity' });
        log.debug({ title: 'entity', details: entity });
    };

    const afterSubmit = (context) => {
        const lineCount = context.newRecord.getLineCount({ sublistId: 'item' });
        for (let i = 0; i < lineCount; i++) {
            const qty = context.newRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
        }
    };

    return { beforeSubmit, afterSubmit };
});
