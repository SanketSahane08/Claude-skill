/**
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/log'], (record, log) => {
    const beforeLoad = (context) => {
        var count = context.newRecord.getLineCount({ sublistId: 'item' });
        for (var i = 1; i <= count; i++) {
            var qty = context.newRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
        }
        nlapiLogExecution('DEBUG', 'beforeLoad', 'done');
    };

    const afterSubmit = (context) => {
        var isActive = context.newRecord.getValue({ fieldId: 'custbody_new_name' });
        if (isActive === 'T') {
            log.debug({ title: 'active', details: 'yes' });
        }

        var results = search.create({
            type: search.Type.CUSTOMER,
            filters: [],
            columns: ['companyname']
        }).run();

        results.each((result) => {
            log.debug({ title: 'row', details: result.getValue({ name: 'companyname' }) });
        });
    };

    return { beforeLoad, afterSubmit: afterSubmit };
});
