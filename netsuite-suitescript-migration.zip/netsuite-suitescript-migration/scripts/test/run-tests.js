#!/usr/bin/env node
/**
 * Test suite for scripts/validate-migration.js. No dependencies — plain Node assertions.
 * Run with: node scripts/test/run-tests.js
 */

'use strict';

const path = require('path');
const { spawnSync } = require('child_process');
const validator = require('../validate-migration.js');

const FIXTURES = path.join(__dirname, 'fixtures');
const VALIDATOR = path.join(__dirname, '..', 'validate-migration.js');

let passed = 0;
let failed = 0;

function check(description, condition) {
  if (condition) {
    passed++;
    console.log(`  PASS: ${description}`);
  } else {
    failed++;
    console.log(`  FAIL: ${description}`);
  }
}

function findingsContain(findings, substring) {
  return findings.some((f) => f.message.includes(substring));
}

function severityCounts(findings) {
  const counts = {};
  for (const f of findings) counts[f.severity] = (counts[f.severity] || 0) + 1;
  return counts;
}

// ---------------------------------------------------------------------------
console.log('\n== good-2.0.js (clean ES5 2.0 conversion) ==');
{
  const report = validator.validateFile(path.join(FIXTURES, 'good-2.0.js'), { target: '2.0', typeOverride: null, originalPath: null });
  const counts = severityCounts(report.findings);
  check('no critical findings', !counts.critical);
  check('no high findings', !counts.high);
  check('@NScriptType detected as ClientScript', report.scriptType === 'ClientScript');
}

console.log('\n== good-2.1.js (clean modern 2.1 conversion) ==');
{
  const report = validator.validateFile(path.join(FIXTURES, 'good-2.1.js'), { target: '2.1', typeOverride: null, originalPath: null });
  const counts = severityCounts(report.findings);
  check('no critical findings', !counts.critical);
  check('no high findings', !counts.high);
  check('shorthand-exported entry points (beforeSubmit, afterSubmit) both recognized', !findingsContain(report.findings, 'No recognized entry point'));
}

console.log('\n== bad.js (deliberately bad, target 2.0, compared against bad-original.js) ==');
{
  const report = validator.validateFile(
    path.join(FIXTURES, 'bad.js'),
    { target: '2.0', typeOverride: null, originalPath: path.join(FIXTURES, 'bad-original.js') }
  );
  const f = report.findings;

  check('flags ES6 arrow function under 2.0 target', findingsContain(f, 'arrow function found'));
  check('flags ES6 const/let under 2.0 target', findingsContain(f, 'const/let declaration found'));
  check('flags leftover nlapi call', findingsContain(f, 'leftover SuiteScript 1.0 call "nlapiLogExecution('));
  check('flags custom ID removed from original (renamed ID)', findingsContain(f, 'custbody_old_name" was present in the original file but is missing'));
  check('flags custom ID added only in converted file', findingsContain(f, 'custbody_new_name" appears in the converted file but not in the original'));
  check('flags 1-based sublist loop', findingsContain(f, 'loop starts at 1'));
  check("flags 'T' checkbox-string comparison", findingsContain(f, "comparison to 'T' found"));
  check('flags missing N/search import used as "search."', findingsContain(f, 'appears to use "search." but no define() dependency binds the name "search"'));
  check('flags .each() with no return true anywhere', findingsContain(f, 'no "return true" anywhere'));
  check('recognizes shorthand export "beforeLoad" alongside "afterSubmit: afterSubmit"', !findingsContain(f, 'No recognized entry point'));

  const counts = severityCounts(f);
  check('has at least one critical finding', (counts.critical || 0) > 0);
  check('has at least one high finding', (counts.high || 0) > 0);
}

// ---------------------------------------------------------------------------
console.log('\n== getExportedNames: shorthand + key:value + nested braces ==');
{
  const source = `
    define(['N/log'], function (log) {
      function beforeLoad(context) { return {}; }
      function afterSubmit(context) { var x = { a: { b: 1 } }; return x; }
      return {
        beforeLoad,
        afterSubmit: afterSubmit,
        'quoted': function () {}
      };
    });
  `;
  const scan = validator.scanSource(source);
  const names = validator.getExportedNames(source, scan.codeNoCommentsNoStrings);
  check('finds shorthand export "beforeLoad"', names.includes('beforeLoad'));
  check('finds key:value export "afterSubmit"', names.includes('afterSubmit'));
  check('finds quoted-key export "quoted"', names.includes('quoted'));
  check('does not get confused by nested braces inside a function body before the real return', names.length === 3);
}

console.log('\n== extractCustomIds: all prefixes recognized ==');
{
  const source = `
    'custbody_a'; 'custcol_b'; 'custrecord_c'; 'custitem_d'; 'custentity_e';
    'customrecord_f'; 'customscript_g'; 'customdeploy_h'; 'customsearch_i';
    'customlist_j'; 'customform_k'; 'custpage_l'; 'custscript_m';
  `;
  const scan = validator.scanSource(source);
  const ids = validator.extractCustomIds(scan.codeNoComments);
  const expectedPrefixes = ['custbody_a', 'custcol_b', 'custrecord_c', 'custitem_d', 'custentity_e',
    'customrecord_f', 'customscript_g', 'customdeploy_h', 'customsearch_i', 'customlist_j',
    'customform_k', 'custpage_l', 'custscript_m'];
  check(`finds all ${expectedPrefixes.length} custom ID prefixes`, expectedPrefixes.every((id) => ids.has(id)));
}

console.log('\n== scanSource: comments and strings do not produce false positives ==');
{
  const source = `
    // nlapiLoadRecord is mentioned only in this comment
    /* also nlapiSubmitRecord here */
    var msg = "call nlapiDeleteRecord if needed";
    nlapiCreateRecord('customer');
  `;
  const scan = validator.scanSource(source);
  check('comment text is blanked out of codeNoComments', !scan.codeNoComments.includes('nlapiLoadRecord'));
  check('block comment text is blanked out', !scan.codeNoComments.includes('nlapiSubmitRecord'));
  check('string content is preserved in codeNoComments (for ID/string diffing)', scan.codeNoComments.includes('nlapiDeleteRecord'));
  check('string content is masked in codeNoCommentsNoStrings (for structural scanning)', !scan.codeNoCommentsNoStrings.includes('nlapiDeleteRecord'));
  check('real code call is still visible in codeNoCommentsNoStrings', scan.codeNoCommentsNoStrings.includes('nlapiCreateRecord'));
}

console.log('\n== classifyVersion / scoreComplexity ==');
{
  const fs = require('fs');
  const ue1 = fs.readFileSync(path.join(FIXTURES, 'inventory-repo', 'SuiteScripts', 'ue_1.js'), 'utf8');
  check('ue_1.js classified as 1.0', validator.classifyVersion(ue1) === '1.0');
  const good21 = fs.readFileSync(path.join(FIXTURES, 'good-2.1.js'), 'utf8');
  check('good-2.1.js classified as 2.x', validator.classifyVersion(good21) === '2.x');
}

// ---------------------------------------------------------------------------
console.log('\n== CLI integration: exit codes ==');
{
  const goodRun = spawnSync('node', [VALIDATOR, '--target', '2.0', path.join(FIXTURES, 'good-2.0.js')]);
  check('clean file exits 0', goodRun.status === 0);

  const badRun = spawnSync('node', [VALIDATOR, '--target', '2.0', '--original', path.join(FIXTURES, 'bad-original.js'), path.join(FIXTURES, 'bad.js')]);
  check('bad file exits 1', badRun.status === 1);

  const usageRun = spawnSync('node', [VALIDATOR]);
  check('no-args usage error exits 2', usageRun.status === 2);

  const badTargetRun = spawnSync('node', [VALIDATOR, '--target', '9.9', path.join(FIXTURES, 'good-2.0.js')]);
  check('invalid --target exits 2', badTargetRun.status === 2);

  const jsonRun = spawnSync('node', [VALIDATOR, '--target', '2.1', '--json', path.join(FIXTURES, 'good-2.1.js')]);
  let jsonParsed = null;
  try { jsonParsed = JSON.parse(jsonRun.stdout.toString()); } catch (e) { /* leave null */ }
  check('--json produces parseable JSON', jsonParsed !== null);
  check('--json report includes the reminder', jsonParsed && typeof jsonParsed.reminder === 'string' && jsonParsed.reminder.includes('Sandbox'));

  const typeOverrideRun = spawnSync('node', [VALIDATOR, '--target', '2.1', '--type', 'ClientScript', path.join(FIXTURES, 'good-2.1.js')]);
  check('--type override accepted and run completes', typeOverrideRun.status === 1 || typeOverrideRun.status === 0);
  check('--type override is reported when it differs from the detected type', typeOverrideRun.stdout.toString().includes('--type override "ClientScript" differs'));

  const inventoryRun = spawnSync('node', [VALIDATOR, 'inventory', path.join(FIXTURES, 'inventory-repo')]);
  const inventoryOut = inventoryRun.stdout.toString();
  check('inventory command runs and produces a Markdown table', inventoryOut.includes('| Script | Type | Version |'));
  check('inventory detects ue_1.js as UserEventScript via SDF XML', inventoryOut.includes('UserEventScript'));
  check('inventory finds the shared_lib.js dependency', inventoryOut.includes('shared_lib.js'));
  check('inventory ends with the Sandbox-testing reminder', inventoryOut.trim().endsWith('references/sandbox-test-checklist.md.'));

  const inventoryJsonRun = spawnSync('node', [VALIDATOR, 'inventory', path.join(FIXTURES, 'inventory-repo'), '--json']);
  let inventoryJson = null;
  try { inventoryJson = JSON.parse(inventoryJsonRun.stdout.toString().split('\n').slice(0, -2).join('\n')); } catch (e) { /* see below */ }
  check('inventory --json produces an array of scripts', inventoryJson && Array.isArray(inventoryJson.scripts) && inventoryJson.scripts.length === 3);
}

// ---------------------------------------------------------------------------
console.log(`\n${passed} passed, ${failed} failed.`);
process.exit(failed > 0 ? 1 : 0);
