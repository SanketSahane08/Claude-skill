#!/usr/bin/env node
/**
 * Static pre-check for a script converted by this skill.
 *
 * Usage:
 *   validate-migration.js [--target 2.1|2.0] [--type <NScriptType>] [--original <old.js>]
 *                          [--json] <converted-file.js> [more-files.js ...]
 *   validate-migration.js inventory <dir> [--json]
 *
 * --target defaults to 2.1 (this skill's default output version). Pass --target 2.0 only
 * for a file whose SS2.0 (ES5-only) override was explicitly confirmed — see "Target Version"
 * in SKILL.md. A bare "2.x" @NApiVersion tag is a legacy-alias WARNING under either target,
 * not an automatic failure.
 *
 * --type overrides script-type detection (useful when @NScriptType is missing or wrong and
 * the real type is known from context).
 *
 * --original <old.js> enables comparison against the pre-conversion source: custom-ID diffing
 * (missing = ERROR, added-only = WARNING), a string-literal review list, and a control-flow
 * keyword count comparison.
 *
 * --json emits a single JSON report to stdout instead of the human-readable text report.
 *
 * This catches mechanical mistakes only. It cannot check business-logic preservation or
 * anything that requires actually running in NetSuite. A clean result means "no obvious
 * mechanical mistakes found," not "migration validated" — see
 * references/business-logic-preservation.md and references/sandbox-test-checklist.md.
 *
 * Exit codes: 0 = no errors, 1 = errors found, 2 = bad usage.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const STATIC_CHECKS_REMINDER =
  'Static checks (this tool, manual diff review) do not prove behavior parity with the ' +
  'original script. NetSuite Sandbox testing is still required — see ' +
  'references/sandbox-test-checklist.md.';

// ---------------------------------------------------------------------------
// Source scanning: strip comments/strings before pattern matching, without
// losing line numbers (every replacement preserves length and newlines) and
// without losing string-literal contents (needed for custom-ID / string-diff
// features). This is a lightweight character scanner, not a real JS parser —
// it handles the common cases (quotes, escapes, // and /* */ comments) well
// enough for a static heuristic checker, not perfectly (e.g. it does not
// disambiguate regex literals from division).
// ---------------------------------------------------------------------------
function scanSource(source) {
  let codeNoComments = '';
  let codeNoCommentsNoStrings = '';
  const strings = [];

  let i = 0;
  const n = source.length;
  let inLineComment = false;
  let inBlockComment = false;
  let inString = null;
  let stringStart = -1;
  let stringBuf = '';

  while (i < n) {
    const c = source[i];
    const c2 = i + 1 < n ? source[i + 1] : '';

    if (inLineComment) {
      if (c === '\n') {
        inLineComment = false;
        codeNoComments += '\n';
        codeNoCommentsNoStrings += '\n';
      } else {
        codeNoComments += ' ';
        codeNoCommentsNoStrings += ' ';
      }
      i++;
      continue;
    }

    if (inBlockComment) {
      if (c === '*' && c2 === '/') {
        inBlockComment = false;
        codeNoComments += '  ';
        codeNoCommentsNoStrings += '  ';
        i += 2;
        continue;
      }
      const out = c === '\n' ? '\n' : ' ';
      codeNoComments += out;
      codeNoCommentsNoStrings += out;
      i++;
      continue;
    }

    if (inString) {
      if (c === '\\' && i + 1 < n) {
        codeNoComments += c + c2;
        codeNoCommentsNoStrings += (c === '\n' ? '\n' : ' ') + (c2 === '\n' ? '\n' : ' ');
        stringBuf += c + c2;
        i += 2;
        continue;
      }
      if (c === inString) {
        codeNoComments += c;
        codeNoCommentsNoStrings += ' ';
        strings.push({ value: stringBuf, index: stringStart, line: lineOf(source, stringStart) });
        inString = null;
        stringBuf = '';
        i++;
        continue;
      }
      codeNoComments += c;
      codeNoCommentsNoStrings += c === '\n' ? '\n' : ' ';
      stringBuf += c;
      i++;
      continue;
    }

    if (c === '/' && c2 === '/') {
      inLineComment = true;
      codeNoComments += '  ';
      codeNoCommentsNoStrings += '  ';
      i += 2;
      continue;
    }
    if (c === '/' && c2 === '*') {
      inBlockComment = true;
      codeNoComments += '  ';
      codeNoCommentsNoStrings += '  ';
      i += 2;
      continue;
    }
    if (c === "'" || c === '"' || c === '`') {
      inString = c;
      stringStart = i;
      stringBuf = '';
      codeNoComments += c;
      codeNoCommentsNoStrings += ' ';
      i++;
      continue;
    }

    codeNoComments += c;
    codeNoCommentsNoStrings += c;
    i++;
  }

  return { codeNoComments, codeNoCommentsNoStrings, strings };
}

function lineOf(source, index) {
  if (index < 0) return 0;
  let line = 1;
  for (let i = 0; i < index && i < source.length; i++) {
    if (source[i] === '\n') line++;
  }
  return line;
}

// ---------------------------------------------------------------------------
// Brace matching (operates on a string with strings/comments already masked
// to spaces, so braces inside string/comment content never confuse it).
// ---------------------------------------------------------------------------
function matchBrace(masked, openIndex) {
  let depth = 0;
  for (let i = openIndex; i < masked.length; i++) {
    const ch = masked[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function splitTopLevel(masked, original, separator) {
  const parts = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < masked.length; i++) {
    const ch = masked[i];
    if ('{[('.includes(ch)) depth++;
    else if ('}])'.includes(ch)) depth--;
    else if (ch === separator && depth === 0) {
      parts.push(original.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(original.slice(start));
  return parts.map((p) => p.trim()).filter(Boolean);
}

// ---------------------------------------------------------------------------
// Script type / entry points
// ---------------------------------------------------------------------------
const ENTRY_POINTS_BY_TYPE = {
  UserEventScript: ['beforeLoad', 'beforeSubmit', 'afterSubmit'],
  ClientScript: [
    'pageInit', 'fieldChanged', 'postSourcing', 'validateField',
    'validateLine', 'validateInsert', 'validateDelete', 'sublistChanged',
    'saveRecord', 'lineInit',
  ],
  Suitelet: ['onRequest'],
  ScheduledScript: ['execute'],
  MapReduceScript: ['getInputData', 'map', 'reduce', 'summarize'],
  Restlet: ['get', 'post', 'put', 'delete'],
  Portlet: ['render'],
  MassUpdateScript: ['each'],
  WorkflowActionScript: ['onAction'],
  BundleInstallationScript: ['beforeInstall', 'afterInstall', 'beforeUpdate', 'afterUpdate', 'beforeUninstall', 'afterUninstall'],
};

const ALL_ENTRY_POINT_NAMES = Array.from(
  new Set(Object.values(ENTRY_POINTS_BY_TYPE).reduce((all, names) => all.concat(names), []))
);

const SERVER_SCRIPT_TYPES = [
  'UserEventScript', 'Suitelet', 'ScheduledScript', 'MapReduceScript', 'Restlet',
  'Portlet', 'MassUpdateScript', 'WorkflowActionScript', 'BundleInstallationScript',
];

const CUSTOM_ID_PREFIXES = [
  'custbody', 'custcol', 'custrecord', 'custitem', 'custentity', 'customrecord',
  'customscript', 'customdeploy', 'customsearch', 'customlist', 'customform',
  'custpage', 'custscript',
];
const CUSTOM_ID_PATTERN = new RegExp(
  `\\b(?:${CUSTOM_ID_PREFIXES.join('|')})_[A-Za-z0-9_]+\\b`, 'g'
);

const LEGACY_API_PATTERN = /\bnlapi[A-Za-z]+\s*\(/g;
const LEGACY_OBJECT_PATTERN = /\bnlobj[A-Za-z]+\s*\(/g;

const ES6_CHECKS = [
  { name: 'arrow function', pattern: /(\([^()]*\)|\b[A-Za-z_$][\w$]*)\s*=>/ },
  { name: 'const/let declaration', pattern: /\b(const|let)\s+[A-Za-z_$]/ },
  { name: 'template literal', pattern: /`[^`]*`/ },
  { name: 'destructuring assignment', pattern: /\b(const|let|var)\s*[{[][^=]*[}\]]\s*=/ },
  { name: 'default parameter', pattern: /function\s*\w*\s*\([^)]*=\s*[^,)]+[^)]*\)/ },
  { name: 'spread/rest operator', pattern: /\.\.\.[A-Za-z_$]/ },
  { name: 'class declaration', pattern: /\bclass\s+[A-Za-z_$]/ },
  { name: 'async/await', pattern: /\b(async\s+function|await\s+)/ },
  { name: 'for...of loop', pattern: /\bfor\s*\(\s*(const|let|var)\s+\w+\s+of\s+/ },
  { name: 'optional chaining', pattern: /\?\./ },
  { name: 'nullish coalescing', pattern: /\?\?/ },
];

const GOVERNANCE_CALL_PATTERNS = [
  /\brecord\.load\s*\(/, /\brecord\.create\s*\(/, /\brecord\.copy\s*\(/,
  /\brecord\.transform\s*\(/, /\brecord\.delete\s*\(/, /\brecord\.submitFields\s*\(/,
  /\.save\s*\(/, /\bsearch\.lookupFields\s*\(/, /\bsearch\.load\s*\(/,
  /\.getRange\s*\(/, /\.each\s*\(/, /\.runPaged\s*\(/, /\bfetch\s*\(/,
  /\bhttps\.get\s*\(/, /\bhttps\.post\s*\(/, /\bhttp\.get\s*\(/, /\bhttp\.post\s*\(/,
  /\bemail\.send\s*\(/, /\btask\.create\s*\(/, /\bfile\.load\s*\(/,
  /\bfile\.create\s*\(/, /\bfile\.delete\s*\(/,
];

const KNOWN_MODULE_NAMESPACES = [
  'record', 'search', 'log', 'runtime', 'email', 'https', 'http', 'file', 'format',
  'task', 'workflow', 'currentRecord', 'serverWidget', 'render', 'xml', 'error',
  'url', 'redirect', 'config', 'crypto', 'encode', 'currency', 'auth', 'transaction',
  'portlet',
];

const CONTROL_FLOW_KEYWORDS = ['if', 'else', 'for', 'while', 'try', 'catch', 'throw', 'switch', 'return'];

function readFile(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function finding(severity, message, line) {
  return { severity, message: line ? `Line ${line}: ${message}` : message };
}

// ---------------------------------------------------------------------------
// Existing checks (kept, lightly adapted to the new scan helper)
// ---------------------------------------------------------------------------
function findLegacyApiUsage(source) {
  const findings = [];
  for (const pattern of [LEGACY_API_PATTERN, LEGACY_OBJECT_PATTERN]) {
    const re = new RegExp(pattern);
    let match;
    while ((match = re.exec(source)) !== null) {
      findings.push(finding('critical', `leftover SuiteScript 1.0 call "${match[0].trim()}"`, lineOf(source, match.index)));
    }
  }
  return findings;
}

function findEs6Usage(source, target) {
  if (target !== '2.0') return [];
  const findings = [];
  for (const check of ES6_CHECKS) {
    const re = new RegExp(check.pattern, 'g');
    let match;
    let count = 0;
    while ((match = re.exec(source)) !== null && count < 5) {
      findings.push(finding(
        'high',
        `${check.name} found ("${match[0].trim().slice(0, 40)}") — this file's confirmed target is SuiteScript 2.0 (ES5-only). See references/es5-output-style.md.`,
        lineOf(source, match.index)
      ));
      count++;
    }
  }
  return findings;
}

function getAnnotation(source, name) {
  const re = new RegExp(`@${name}\\s+([^\\s*]+)`);
  const match = source.match(re);
  return match ? match[1].replace(/["']/g, '') : null;
}

function checkApiVersion(apiVersion, target) {
  if (!apiVersion) {
    return [finding('critical', 'No @NApiVersion annotation found.')];
  }
  if (apiVersion === '2.x') {
    return [finding('medium', 'Legacy "2.x" @NApiVersion alias found — NetSuite expects an exact version tag. Resolve to the confirmed target (2.0 or 2.1) explicitly.')];
  }
  if (apiVersion !== target) {
    return [finding('critical', `@NApiVersion is "${apiVersion}", not "${target}". This file's confirmed target version is ${target} — flag any other tag (1.0, or a 2.x that doesn't match) rather than treating it as already migrated.`)];
  }
  return [];
}

function checkModuleStructure(source, target) {
  const issues = [];
  if (!/\bdefine\s*\(/.test(source)) {
    issues.push(finding('critical', 'No define() module wrapper found — this does not look like a SuiteScript 2.x file.'));
    return issues;
  }
  const defineIdx = source.indexOf('define');
  const factoryIsFunctionExpr = /function\s*\(/.test(source.slice(defineIdx));
  const factoryIsArrow = /\)\s*=>/.test(source.slice(defineIdx, defineIdx + 200));

  if (target === '2.0' && !factoryIsFunctionExpr) {
    issues.push(finding('high', 'define() factory does not appear to use a function expression. Under the 2.0 (ES5-only) override it must be `function (dep1, dep2) {...}`, never an arrow function.'));
  } else if (target !== '2.0' && !factoryIsFunctionExpr && !factoryIsArrow) {
    issues.push(finding('high', 'define() factory does not appear to use either a function expression or an arrow function — check the module-loading shell is well-formed.'));
  }
  if (!/return\s*\{/.test(source)) {
    issues.push(finding('critical', 'No return { ... } found in the define() factory. Without an explicit export object, NetSuite will not register any entry points for this script.'));
  }
  return issues;
}

function checkDefineModulesAndParams(source) {
  const issues = [];
  const defineMatch = source.match(/define\s*\(\s*\[([^\]]*)\]\s*,\s*(?:function\s*\(([^)]*)\)|\(([^)]*)\)\s*=>)/);
  if (!defineMatch) return { issues, modules: [], params: [] };

  const modules = defineMatch[1].split(',').map((s) => s.trim().replace(/["']/g, '')).filter(Boolean);
  const paramsRaw = defineMatch[2] !== undefined ? defineMatch[2] : defineMatch[3];
  const params = paramsRaw.split(',').map((s) => s.trim()).filter(Boolean);

  if (modules.length !== params.length) {
    issues.push(finding('high', `define() dependency array has ${modules.length} entries but the factory function has ${params.length} parameters — these must line up 1:1 in the same order.`));
  }
  return { issues, modules, params };
}

// ---------------------------------------------------------------------------
// Robust entry-point / export parsing (handles ES6 shorthand and nested
// braces, unlike a naive "return\s*\{([^}]*)\}" regex)
// ---------------------------------------------------------------------------
function findReturnObjectSpan(masked) {
  // A file can legitimately contain more than one "return { ... }" (helper
  // functions returning object literals before the module's own export
  // statement). The module-level export is virtually always the LAST one
  // textually, so prefer the last valid match rather than the first.
  const re = /\breturn\s*\{/g;
  let match;
  let lastSpan = null;
  while ((match = re.exec(masked)) !== null) {
    const braceStart = match.index + match[0].length - 1;
    const braceEnd = matchBrace(masked, braceStart);
    if (braceEnd !== -1) lastSpan = [braceStart, braceEnd];
  }
  return lastSpan;
}

function getExportedNames(source, masked) {
  const span = findReturnObjectSpan(masked);
  if (!span) return [];
  const [start, end] = span;
  const innerMasked = masked.slice(start + 1, end);
  const innerOriginal = source.slice(start + 1, end);
  const parts = splitTopLevel(innerMasked, innerOriginal, ',');

  const names = [];
  for (const part of parts) {
    const trimmed = part.trim();
    if (!trimmed || trimmed.startsWith('...')) continue;
    let m = trimmed.match(/^([A-Za-z_$][\w$]*)\s*:/);
    if (m) { names.push(m[1]); continue; }
    m = trimmed.match(/^(['"])([^'"]*)\1\s*:/);
    if (m) { names.push(m[2]); continue; }
    m = trimmed.match(/^([A-Za-z_$][\w$]*)\s*$/);
    if (m) { names.push(m[1]); continue; }
  }
  return names;
}

function isLibraryModule(exportedNames, scriptType) {
  if (scriptType) return false;
  if (exportedNames.length === 0) return false;
  return !exportedNames.some((name) => ALL_ENTRY_POINT_NAMES.includes(name));
}

function checkEntryPoints(source, masked, scriptType, exportedNames) {
  const issues = [];
  const expected = ENTRY_POINTS_BY_TYPE[scriptType];
  if (!expected) {
    issues.push(finding('medium', `Unrecognized @NScriptType "${scriptType}" — skipping entry point check.`));
    return issues;
  }

  const found = expected.filter((fn) => exportedNames.includes(fn) || new RegExp(`function\\s+${fn}\\s*\\(`).test(source));
  if (found.length === 0) {
    issues.push(finding('high', `No recognized entry point for @NScriptType "${scriptType}" found. Expected at least one of: ${expected.join(', ')}.`));
  }

  const extras = exportedNames.filter((name) => !expected.includes(name));
  for (const extra of extras) {
    if (scriptType === 'ClientScript') {
      issues.push(finding('info', `Export "${extra}" is not a recognized ClientScript entry point — likely a button handler or helper exposed intentionally; confirm it's actually wired up somewhere (form button, HTML onclick).`));
    } else {
      issues.push(finding('medium', `Export "${extra}" is not a recognized entry point for @NScriptType "${scriptType}" — confirm it's intentional (a shared helper exported for other modules) rather than a leftover or a misspelled entry point name.`));
    }
  }
  return issues;
}

function checkRecordModuleMisuse(source, scriptType) {
  const issues = [];
  if (scriptType !== 'ClientScript') return issues;
  const importsRecord = /define\s*\(\s*\[[^\]]*['"]N\/record['"]/.test(source);
  const importsCurrentRecord = /['"]N\/currentRecord['"]/.test(source);
  if (importsRecord && !importsCurrentRecord) {
    issues.push(finding('medium', 'Client script imports N/record but not N/currentRecord. If this script reads/writes the on-screen record, use N/currentRecord instead of loading a separate server-side copy with N/record.'));
  }
  return issues;
}

// ---------------------------------------------------------------------------
// New behavior checks (task 3d)
// ---------------------------------------------------------------------------
function checkCheckboxTFComparisons(masked, original) {
  const findings = [];
  const re = /(===|==|!==|!=)\s*['"]([TF])['"]|['"]([TF])['"]\s*(===|==|!==|!=)/g;
  let match;
  while ((match = re.exec(masked)) !== null) {
    findings.push(finding('medium', `comparison to '${match[2] || match[3]}' found — in SS2.x, getValue()/currentRecord.getValue() return a boolean for checkbox fields, not 'T'/'F' strings. Compare with true/false instead (corrections.md #4).`, lineOf(original, match.index)));
  }
  return findings;
}

function checkOneBasedSublistLoop(masked, original) {
  const findings = [];
  const re = /\bfor\s*\(\s*(?:var|let)\s+(\w+)\s*=\s*1\s*;\s*\1\s*<=\s*/g;
  let match;
  while ((match = re.exec(masked)) !== null) {
    findings.push(finding('high', `loop starts at 1 ("${match[0].trim()}") — sublist lines are 0-based in SS2.x. Confirm this isn't a leftover 1-based sublist loop.`, lineOf(original, match.index)));
  }
  return findings;
}

function checkEachWithoutReturnTrue(masked, original) {
  if (!/\.each\s*\(/.test(masked)) return [];
  if (/\breturn\s+true\b/.test(masked)) return [];
  const idx = masked.search(/\.each\s*\(/);
  return [finding('medium', 'this file calls .each() but contains no "return true" anywhere — the ResultSet.each() callback must return true to continue past the first row.', lineOf(original, idx))];
}

function checkNullChecksNearSearchResults(masked, original) {
  const findings = [];
  const lines = masked.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (/\.getRange\s*\(|\.run\s*\(/.test(lines[i])) {
      const windowStart = Math.max(0, i - 2);
      const windowEnd = Math.min(lines.length - 1, i + 2);
      for (let j = windowStart; j <= windowEnd; j++) {
        if (/[=!]==?\s*null/.test(lines[j]) || /\bnull\s*[=!]==?/.test(lines[j])) {
          findings.push(finding('info', `possible null-check near a search run()/getRange() call (line ${j + 1}) — SS2.x search results return [] for "no results," never null, unlike SS1.0's nlapiSearchRecord. Confirm the condition was rewritten per corrections.md #2, not just carried over.`, i + 1));
          break;
        }
      }
    }
  }
  return findings;
}

function checkCurrentLineApisWithoutDynamic(masked, original) {
  const hasCurrentLineApi = /\b(selectNewLine|selectLine|setCurrentSublistValue|commitLine)\s*\(/.test(masked);
  if (!hasCurrentLineApi) return [];
  if (/isDynamic\s*:\s*true/.test(masked)) return [];
  const idx = masked.search(/\b(selectNewLine|selectLine|setCurrentSublistValue|commitLine)\s*\(/);
  return [finding('high', 'current-line sublist API (selectNewLine/selectLine/setCurrentSublistValue/commitLine) used without isDynamic: true anywhere in the file — these APIs require dynamic mode. See corrections.md #5.', lineOf(original, idx))];
}

function checkSetValueTF(masked, original) {
  const findings = [];
  const re = /\bsetValue\s*\(/g;
  let match;
  while ((match = re.exec(masked)) !== null) {
    const window = masked.slice(match.index, match.index + 200);
    const tfMatch = window.match(/\bvalue\s*:\s*['"](T|F)['"]/);
    if (tfMatch) {
      findings.push(finding('medium', `setValue() called with value: '${tfMatch[1]}' — checkbox fields expect a boolean (true/false), not the SS1.0-style 'T'/'F' string.`, lineOf(original, match.index)));
    }
  }
  return findings;
}

function checkAsyncEntryPoints(masked, original, scriptType) {
  if (scriptType === 'ClientScript') return [];
  const findings = [];
  for (const name of ALL_ENTRY_POINT_NAMES) {
    const patterns = [
      new RegExp(`\\basync\\s+function\\s+${name}\\s*\\(`),
      new RegExp(`\\b${name}\\s*:\\s*async\\b`),
      new RegExp(`\\bconst\\s+${name}\\s*=\\s*async\\b`),
    ];
    for (const p of patterns) {
      const match = masked.match(p);
      if (match) {
        findings.push(finding('high', `entry point "${name}" is declared async — NetSuite does not await entry-point return values outside Client Scripts; a returned Promise is not handled the way the script likely intends.`, lineOf(original, masked.indexOf(match[0]))));
        break;
      }
    }
  }
  return findings;
}

function checkBrowserGlobalsInServerScript(masked, original, scriptType) {
  if (!SERVER_SCRIPT_TYPES.includes(scriptType)) return [];
  const findings = [];
  const re = /\b(window|document|localStorage)\s*\./g;
  let match;
  while ((match = re.exec(masked)) !== null) {
    findings.push(finding('critical', `browser global "${match[1]}" used in a server-side script (@NScriptType ${scriptType}) — server scripts run on NetSuite's server, not in a browser; this will throw.`, lineOf(original, match.index)));
  }
  return findings;
}

function checkClientOnlyModulesInServerScript(source, scriptType) {
  if (scriptType === 'ClientScript' || !scriptType) return [];
  const findings = [];
  if (/['"]N\/currentRecord['"]/.test(source)) {
    findings.push(finding('critical', `N/currentRecord imported in a non-Client script (@NScriptType ${scriptType}) — N/currentRecord only works in Client Script context; use N/record and the context's record object instead.`));
  }
  if (/['"]N\/ui\/dialog['"]/.test(source)) {
    findings.push(finding('critical', `N/ui/dialog imported in a non-Client script (@NScriptType ${scriptType}) — dialogs require a browser UI; this module only works in Client Scripts.`));
  }
  return findings;
}

const SERVER_WIDGET_EXPECTED_TYPES = ['Suitelet', 'UserEventScript'];
function checkServerWidgetInUnexpectedType(source, scriptType) {
  if (!scriptType || SERVER_WIDGET_EXPECTED_TYPES.includes(scriptType)) return [];
  if (/['"]N\/ui\/serverWidget['"]/.test(source)) {
    return [finding('medium', `N/ui/serverWidget imported in @NScriptType "${scriptType}" — this script type doesn't normally build UI forms; confirm this import is actually needed.`)];
  }
  return [];
}

function checkModuleImportUsage(source, modules, params) {
  const findings = [];
  for (let i = 0; i < params.length; i++) {
    const paramName = params[i];
    const modulePath = modules[i] || '(unknown module)';
    if (!paramName) continue;
    const usageRe = new RegExp(`\\b${paramName}\\s*\\.`);
    const bodyAfterDefine = source.slice(source.indexOf(params.join(',')) || 0);
    if (!usageRe.test(bodyAfterDefine) && !usageRe.test(source)) {
      findings.push(finding('medium', `module "${modulePath}" is imported as "${paramName}" but never referenced (no "${paramName}." usage found) — remove it if truly unused.`));
    }
  }
  const importedSet = new Set(params);
  for (const ns of KNOWN_MODULE_NAMESPACES) {
    if (importedSet.has(ns)) continue;
    const re = new RegExp(`\\b${ns}\\s*\\.[A-Za-z]`);
    if (re.test(source)) {
      findings.push(finding('medium', `code appears to use "${ns}." but no define() dependency binds the name "${ns}" — confirm the matching N/* module is imported (or that "${ns}" is a local variable, not a module reference).`));
    }
  }
  return findings;
}

function checkGovernanceCallsInLoops(masked, original) {
  const findings = [];
  let totalGovernanceCalls = 0;
  for (const p of GOVERNANCE_CALL_PATTERNS) {
    const re = new RegExp(p.source, 'g');
    let m;
    while ((m = re.exec(masked)) !== null) totalGovernanceCalls++;
  }

  const loopStartRe = /\b(for|while)\s*\(|\.(forEach|each)\s*\(/g;
  let loopMatch;
  while ((loopMatch = loopStartRe.exec(masked)) !== null) {
    const braceIdx = masked.indexOf('{', loopMatch.index);
    if (braceIdx === -1) continue;
    const braceEnd = matchBrace(masked, braceIdx);
    if (braceEnd === -1) continue;
    const body = masked.slice(braceIdx, braceEnd);
    for (const p of GOVERNANCE_CALL_PATTERNS) {
      const m = body.match(p);
      if (m) {
        findings.push(finding('medium', `governance-bearing call "${m[0].trim()}" found inside a loop body (loop starting line ${lineOf(original, loopMatch.index)}) — confirm this is intentional and governance-safe for the expected data volume.`, lineOf(original, loopMatch.index)));
      }
    }
  }

  if (totalGovernanceCalls > 0) {
    findings.push(finding('info', `${totalGovernanceCalls} governance-bearing call(s) found in this file (record load/create/copy/transform/delete/submitFields, .save, search.lookupFields/load, getRange/each/runPaged, http(s) calls, email.send, task.create, file ops) — compare this count with the original to sanity-check governance usage didn't change.`));
  }
  return findings;
}

function checkMigrationReviewMarkers(original) {
  const findings = [];
  const re = /\/\/\s*MIGRATION-REVIEW:\s*(.*)/g;
  let match;
  while ((match = re.exec(original)) !== null) {
    findings.push(finding('info', `unresolved MIGRATION-REVIEW marker: ${match[1].trim()}`, lineOf(original, match.index)));
  }
  return findings;
}

// ---------------------------------------------------------------------------
// --original comparison (custom IDs, string literals, control-flow counts)
// ---------------------------------------------------------------------------
function extractCustomIds(codeNoComments) {
  const ids = new Set();
  let match;
  const re = new RegExp(CUSTOM_ID_PATTERN);
  while ((match = re.exec(codeNoComments)) !== null) ids.add(match[0]);
  return ids;
}

function extractControlFlowCounts(codeNoCommentsNoStrings) {
  const counts = {};
  for (const kw of CONTROL_FLOW_KEYWORDS) {
    const re = new RegExp(`\\b${kw}\\b`, 'g');
    counts[kw] = (codeNoCommentsNoStrings.match(re) || []).length;
  }
  return counts;
}

function compareWithOriginal(originalSource, convertedSource) {
  const findings = [];
  const origScan = scanSource(originalSource);
  const convScan = scanSource(convertedSource);

  const origIds = extractCustomIds(origScan.codeNoComments);
  const convIds = extractCustomIds(convScan.codeNoComments);

  for (const id of origIds) {
    if (!convIds.has(id)) {
      findings.push(finding('critical', `custom ID "${id}" was present in the original file but is missing from the converted file — possible unintended rename or removal. Custom IDs must never change during migration.`));
    }
  }
  for (const id of convIds) {
    if (!origIds.has(id)) {
      findings.push(finding('medium', `custom ID "${id}" appears in the converted file but not in the original — confirm this isn't an accidentally-copied example ID (corrections.md #3) or an unintended addition.`));
    }
  }

  const origStrings = new Set(origScan.strings.map((s) => s.value).filter((v) => v.length > 1));
  const convStrings = new Set(convScan.strings.map((s) => s.value).filter((v) => v.length > 1));
  const onlyInOriginal = [...origStrings].filter((s) => !convStrings.has(s));
  const onlyInConverted = [...convStrings].filter((s) => !origStrings.has(s));
  if (onlyInOriginal.length > 0) {
    findings.push(finding('info', `${onlyInOriginal.length} string literal(s) present only in the original file (review list, first 10 shown): ${JSON.stringify(onlyInOriginal.slice(0, 10))}`));
  }
  if (onlyInConverted.length > 0) {
    findings.push(finding('info', `${onlyInConverted.length} string literal(s) present only in the converted file (review list, first 10 shown): ${JSON.stringify(onlyInConverted.slice(0, 10))}`));
  }

  const origCounts = extractControlFlowCounts(origScan.codeNoCommentsNoStrings);
  const convCounts = extractControlFlowCounts(convScan.codeNoCommentsNoStrings);
  const warnOnDiff = new Set(['try', 'catch', 'throw', 'if', 'for', 'while']);
  for (const kw of CONTROL_FLOW_KEYWORDS) {
    if (origCounts[kw] !== convCounts[kw]) {
      const severity = warnOnDiff.has(kw) ? 'medium' : 'info';
      findings.push(finding(severity, `"${kw}" count differs: original has ${origCounts[kw]}, converted has ${convCounts[kw]} — confirm this reflects an intentional, behavior-preserving restructuring (e.g. a loop shape changing), not a dropped branch.`));
    }
  }

  return findings;
}

// ---------------------------------------------------------------------------
// Per-file validation
// ---------------------------------------------------------------------------
function validateFile(filePath, { target, typeOverride, originalPath }) {
  const source = readFile(filePath);
  const scan = scanSource(source);
  const { codeNoComments, codeNoCommentsNoStrings } = scan;

  const detectedScriptType = getAnnotation(source, 'NScriptType');
  const scriptType = typeOverride || detectedScriptType;
  const apiVersion = getAnnotation(source, 'NApiVersion');
  const exportedNames = getExportedNames(source, codeNoCommentsNoStrings);

  const findings = [];
  if (typeOverride && detectedScriptType && typeOverride !== detectedScriptType) {
    findings.push(finding('info', `--type override "${typeOverride}" differs from the detected @NScriptType "${detectedScriptType}" — using the override.`));
  }

  findings.push(...checkApiVersion(apiVersion, target));
  findings.push(...findLegacyApiUsage(codeNoComments));
  findings.push(...checkModuleStructure(source, target));
  findings.push(...findEs6Usage(codeNoCommentsNoStrings, target));

  const { issues: defineIssues, modules, params } = checkDefineModulesAndParams(source);
  findings.push(...defineIssues);

  if (scriptType) {
    findings.push(...checkEntryPoints(source, codeNoCommentsNoStrings, scriptType, exportedNames));
    findings.push(...checkRecordModuleMisuse(source, scriptType));
  } else if (isLibraryModule(exportedNames, scriptType)) {
    findings.push(finding('low', 'No @NScriptType found, and none of the exported functions match a known script-type entry point — treated as a library/helper module (Shape A), not an incomplete conversion.'));
  } else {
    findings.push(finding('critical', 'No @NScriptType annotation found — cannot check entry points.'));
  }

  findings.push(...checkCheckboxTFComparisons(codeNoComments, source));
  findings.push(...checkOneBasedSublistLoop(codeNoCommentsNoStrings, source));
  findings.push(...checkEachWithoutReturnTrue(codeNoCommentsNoStrings, source));
  findings.push(...checkNullChecksNearSearchResults(codeNoCommentsNoStrings, source));
  findings.push(...checkCurrentLineApisWithoutDynamic(codeNoCommentsNoStrings, source));
  findings.push(...checkSetValueTF(codeNoComments, source));
  findings.push(...checkAsyncEntryPoints(codeNoCommentsNoStrings, source, scriptType));
  findings.push(...checkBrowserGlobalsInServerScript(codeNoCommentsNoStrings, source, scriptType));
  findings.push(...checkClientOnlyModulesInServerScript(source, scriptType));
  findings.push(...checkServerWidgetInUnexpectedType(source, scriptType));
  findings.push(...checkModuleImportUsage(source, modules, params));
  findings.push(...checkGovernanceCallsInLoops(codeNoCommentsNoStrings, source));
  findings.push(...checkMigrationReviewMarkers(source));

  if (originalPath) {
    const originalSource = readFile(originalPath);
    findings.push(...compareWithOriginal(originalSource, source));
  }

  return { file: filePath, apiVersion, scriptType: scriptType || null, findings };
}

const SEVERITY_ORDER = ['critical', 'high', 'medium', 'low', 'info'];

function printReport(report) {
  console.log(`\n${report.file}`);
  console.log(`  @NApiVersion: ${report.apiVersion || '(none found)'}`);
  console.log(`  @NScriptType: ${report.scriptType || '(none found)'}`);

  if (report.findings.length === 0) {
    console.log('  No mechanical issues found. This does NOT mean the migration is validated ' +
      '— business logic preservation and NetSuite-side behavior still require review and ' +
      'Sandbox testing. See references/business-logic-preservation.md.');
    return;
  }

  const bySeverity = {};
  for (const f of report.findings) {
    (bySeverity[f.severity] = bySeverity[f.severity] || []).push(f);
  }
  for (const severity of SEVERITY_ORDER) {
    const items = bySeverity[severity];
    if (!items) continue;
    console.log(`  ${severity.toUpperCase()} (${items.length})`);
    for (const item of items) console.log(`    - ${item.message}`);
  }

  const hasBlocking = (bySeverity.critical || []).length > 0 || (bySeverity.high || []).length > 0;
  console.log(`  Validation result: ${hasBlocking ? 'FAIL' : 'PASS (mechanical checks only)'}`);
}

// ---------------------------------------------------------------------------
// inventory <dir> command
// ---------------------------------------------------------------------------
function walkJsFiles(dir) {
  const results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...walkJsFiles(full));
    } else if (entry.isFile() && full.endsWith('.js')) {
      results.push(full);
    }
  }
  return results;
}

function findSdfScriptTypeForFile(dir, jsFilePath) {
  const xmlFiles = walkXmlFiles(dir);
  const base = path.basename(jsFilePath);
  for (const xmlFile of xmlFiles) {
    const xml = fs.readFileSync(xmlFile, 'utf8');
    if (xml.includes(base)) {
      const scriptfileMatch = xml.match(/<scriptfile>\s*\[?\/?([^<\]\s]*)\]?\s*<\/scriptfile>/);
      const rootTagMatch = xml.match(/<(\w+script)\b/i);
      if (scriptfileMatch && scriptfileMatch[1].endsWith(base) && rootTagMatch) {
        return sdfRootTagToScriptType(rootTagMatch[1]);
      }
    }
  }
  return null;
}

function walkXmlFiles(dir) {
  const results = [];
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return results;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) results.push(...walkXmlFiles(full));
    else if (entry.isFile() && full.endsWith('.xml')) results.push(full);
  }
  return results;
}

const SDF_ROOT_TAG_MAP = {
  usereventscript: 'UserEventScript',
  clientscript: 'ClientScript',
  suitelet: 'Suitelet',
  scheduledscript: 'ScheduledScript',
  mapreducescript: 'MapReduceScript',
  restlet: 'Restlet',
  portlet: 'Portlet',
  massupdatescript: 'MassUpdateScript',
  workflowactionscript: 'WorkflowActionScript',
  bundleinstallationscript: 'BundleInstallationScript',
};

function sdfRootTagToScriptType(tag) {
  return SDF_ROOT_TAG_MAP[tag.toLowerCase()] || null;
}

function heuristicScriptType(source, exportedNames) {
  for (const [type, entryPoints] of Object.entries(ENTRY_POINTS_BY_TYPE)) {
    if (entryPoints.some((name) => exportedNames.includes(name) || new RegExp(`function\\s+${name}\\s*\\(`).test(source))) {
      return type;
    }
  }
  return null;
}

function classifyVersion(source) {
  const hasNlapi = LEGACY_API_PATTERN.test(source) || LEGACY_OBJECT_PATTERN.test(source);
  const hasDefine = /\bdefine\s*\(/.test(source);
  const apiVersion = getAnnotation(source, 'NApiVersion');

  if (hasNlapi && hasDefine) return 'MIXED';
  if (hasNlapi || (!hasDefine && !apiVersion)) return '1.0';
  if (apiVersion === '1.0') return '1.0';
  return '2.x';
}

function scoreComplexity(source) {
  let score = 0;
  const lineCount = source.split('\n').length;
  score += lineCount < 100 ? 1 : lineCount <= 500 ? 2 : 3;
  const nlapiCalls = (source.match(LEGACY_API_PATTERN) || []).length;
  score += nlapiCalls < 10 ? 1 : nlapiCalls <= 30 ? 2 : 3;
  if (/nlapiYieldScript|nlapiSetRecoveryPoint/.test(source)) score += 3;
  if (/selectNewLineItem|setCurrentLineItemValue|commitLineItem/.test(source)) score += 2;

  if (score <= 4) return 'Low';
  if (score <= 7) return 'Medium';
  return 'High';
}

function findLibraryDependencies(source, allFiles) {
  const deps = [];
  const includeRe = /nlapiIncludeScript\s*\(\s*['"]([^'"]+)['"]/g;
  let match;
  while ((match = includeRe.exec(source)) !== null) deps.push(match[1]);
  return deps;
}

function runInventory(dir, jsonOutput) {
  const files = walkJsFiles(dir);
  const rows = [];

  for (const file of files) {
    const source = readFile(file);
    const masked = scanSource(source).codeNoCommentsNoStrings;
    const exportedNames = getExportedNames(source, masked);
    const version = classifyVersion(source);

    let scriptType = findSdfScriptTypeForFile(dir, file);
    let scriptTypeConfirmed = scriptType ? 'from SDF Object XML' : null;
    if (!scriptType) {
      scriptType = heuristicScriptType(source, exportedNames);
      scriptTypeConfirmed = scriptType ? 'CONFIRM (heuristic — no SDF XML match found)' : null;
    }

    const dependencies = findLibraryDependencies(source, files);
    const nlapiCalls = Array.from(new Set((source.match(LEGACY_API_PATTERN) || []).map((s) => s.replace(/\s*\($/, ''))));

    rows.push({
      file: path.relative(dir, file),
      type: scriptType || 'Unknown (CONFIRM)',
      typeConfirmedVia: scriptTypeConfirmed || 'undetected',
      version,
      dependencies,
      nlapiCalls,
      complexity: version === '1.0' || version === 'MIXED' ? scoreComplexity(source) : 'N/A',
      status: version === 'MIXED' ? 'Blocked — mixed 1.0/2.x code in one file' : null,
    });
  }

  if (jsonOutput) {
    console.log(JSON.stringify({ directory: dir, scripts: rows }, null, 2));
  } else {
    console.log(`\n## Script Inventory: ${dir}\n`);
    console.log('| Script | Type | Version | Dependencies | Complexity | Status |');
    console.log('|---|---|---|---|---|---|');
    for (const row of rows) {
      const typeCell = row.typeConfirmedVia.startsWith('CONFIRM') ? `${row.type} (${row.typeConfirmedVia})` : row.type;
      const deps = row.dependencies.length ? row.dependencies.join(', ') : 'None found';
      const status = row.status || (row.version === '1.0' ? 'Needs migration' : row.version === 'MIXED' ? 'Blocked' : 'Already on 2.x');
      console.log(`| ${row.file} | ${typeCell} | ${row.version} | ${deps} | ${row.complexity} | ${status} |`);
    }
    const distinctApis = Array.from(new Set(rows.flatMap((r) => r.nlapiCalls))).sort();
    if (distinctApis.length) {
      console.log(`\n### Distinct SS1.0 APIs found (${distinctApis.length})\n`);
      console.log(distinctApis.join(', '));
    }
  }

  console.log(`\n${STATIC_CHECKS_REMINDER}`);
  const hasBlocked = rows.some((r) => r.status);
  return hasBlocked ? 1 : 0;
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
function usageAndExit(message) {
  if (message) console.error(message);
  console.error('Usage: validate-migration.js [--target 2.1|2.0] [--type <NScriptType>] [--original <old.js>] [--json] <file...>');
  console.error('       validate-migration.js inventory <dir> [--json]');
  process.exit(2);
}

function parseArgs(args) {
  const opts = { target: '2.1', typeOverride: null, originalPath: null, json: false, files: [] };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--target') {
      opts.target = args[++i];
    } else if (arg.startsWith('--target=')) {
      opts.target = arg.split('=')[1];
    } else if (arg === '--type') {
      opts.typeOverride = args[++i];
    } else if (arg.startsWith('--type=')) {
      opts.typeOverride = arg.split('=')[1];
    } else if (arg === '--original') {
      opts.originalPath = args[++i];
    } else if (arg.startsWith('--original=')) {
      opts.originalPath = arg.split('=')[1];
    } else if (arg === '--json') {
      opts.json = true;
    } else if (arg.startsWith('--')) {
      usageAndExit(`Unknown flag: ${arg}`);
    } else {
      opts.files.push(arg);
    }
  }
  if (opts.target !== '2.0' && opts.target !== '2.1') {
    usageAndExit(`Invalid --target "${opts.target}" — must be 2.0 or 2.1.`);
  }
  return opts;
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0) usageAndExit();

  if (args[0] === 'inventory') {
    const dir = args[1];
    if (!dir) usageAndExit('inventory requires a directory argument.');
    const jsonOutput = args.includes('--json');
    if (!fs.existsSync(dir)) usageAndExit(`Directory not found: ${dir}`);
    process.exit(runInventory(dir, jsonOutput));
    return;
  }

  const opts = parseArgs(args);
  if (opts.files.length === 0) usageAndExit('No files given.');
  if (opts.originalPath && !fs.existsSync(opts.originalPath)) {
    usageAndExit(`--original file not found: ${opts.originalPath}`);
  }

  if (!opts.json) {
    console.log(`Validating against target: SuiteScript ${opts.target}${opts.target === '2.1' ? " (this skill's default)" : ' (explicit override)'}`);
  }

  let hasBlockingIssues = false;
  const reports = [];
  for (const file of opts.files) {
    if (!fs.existsSync(file)) {
      reports.push({ file, apiVersion: null, scriptType: null, findings: [finding('critical', 'File not found.')] });
      hasBlockingIssues = true;
      continue;
    }
    const report = validateFile(path.resolve(file), opts);
    reports.push(report);
    if (report.findings.some((f) => f.severity === 'critical' || f.severity === 'high')) {
      hasBlockingIssues = true;
    }
  }

  if (opts.json) {
    console.log(JSON.stringify({ target: opts.target, reports, reminder: STATIC_CHECKS_REMINDER }, null, 2));
  } else {
    for (const report of reports) printReport(report);
    console.log(`\n${STATIC_CHECKS_REMINDER}`);
  }

  process.exit(hasBlockingIssues ? 1 : 0);
}

module.exports = {
  scanSource, lineOf, getExportedNames, extractCustomIds, extractControlFlowCounts,
  validateFile, compareWithOriginal, classifyVersion, scoreComplexity,
};

if (require.main === module) {
  main();
}
